<?php
session_start();
include 'Connection_db.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $app_id = $_POST['id'];

    // Move selected applicant to another table (selected_applicants)
    $stmt = $conn->prepare("INSERT INTO selected_applicants (job_id, name, email, cover_letter, cv_file, applied_at)
        SELECT job_id, applicant_name, applicant_email, cover_letter, cv_file, application_date FROM job_applications WHERE id = ?");
    $stmt->bind_param("i", $app_id);

    if ($stmt->execute()) {
        // Remove from job_applications
        $delete_stmt = $conn->prepare("DELETE FROM job_applications WHERE id = ?");
        $delete_stmt->bind_param("i", $app_id);
        $delete_stmt->execute();

        echo "success";
    } else {
        echo "error";
    }
}
?>
