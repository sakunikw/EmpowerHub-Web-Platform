<?php
include 'Connection_db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $country = $_POST['country'];
    $linkedin = $_POST['linkedin'];
    $experience = $_POST['experience'];
    $industry = $_POST['industry'];
    $bio = $_POST['bio'];
    $motivation = $_POST['motivation'];
    $availability = $_POST['availability'];
    $status = 'pending';

    // File upload handling
    $target_dir = "uploads/";

    // Handle profile picture
    if (!empty($_FILES["profile_picture"]["name"])) {
        $profile_picture_path = $target_dir . basename($_FILES["profile_picture"]["name"]);
        move_uploaded_file($_FILES["profile_picture"]["tmp_name"], $profile_picture_path);
    } else {
        $profile_picture_path = "uploads/default-avatar.png"; // Default avatar
    }

    // Handle certificate
    $certificate_path = $target_dir . basename($_FILES["certificate"]["name"]);
    move_uploaded_file($_FILES["certificate"]["tmp_name"], $certificate_path);

    // Handle government ID
    $gov_id_path = $target_dir . basename($_FILES["gov_id"]["name"]);
    move_uploaded_file($_FILES["gov_id"]["tmp_name"], $gov_id_path);

    // Insert data into the database
    $sql = "INSERT INTO mentor_verification (full_name, email, phone, country, linkedin, experience, industry, bio, motivation, availability, profile_picture, certificate_path, gov_id_path, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";

    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("sssssissssssss", $full_name, $email, $phone, $country, $linkedin, $experience, $industry, $bio, $motivation, $availability, $profile_picture_path, $certificate_path, $gov_id_path, $status);

        if ($stmt->execute()) {
            echo "<script>alert('Verification submitted successfully!'); window.location.href='MentorHome.php';</script>";
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    }
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mentor Verification Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            margin: auto;
        }
        h2 { text-align: center; }
        label { font-weight: bold; }
        input, select, textarea {
            width: 100%; padding: 8px; margin: 8px 0;
            border: 1px solid #ccc; border-radius: 4px;
        }
        button {
            width: 100%; background: #28a745; color: white;
            padding: 10px; border: none; cursor: pointer; font-size: 16px;
        }
        button:hover { background: #218838; }
    </style>
</head>
<body>

<div class="container">
    <h2>Mentor Verification Form</h2>
    <form action="" method="POST" enctype="multipart/form-data">

        <label>Full Name</label>
        <input type="text" name="full_name" required>

        <label>Email</label>
        <input type="email" name="email" required>

        <label>Phone</label>
        <input type="text" name="phone" required>

        <label>Country</label>
        <input type="text" name="country" required>

        <label>LinkedIn Profile URL</label>
        <input type="url" name="linkedin" required>

        <label>Years of Experience</label>
        <input type="number" name="experience" required>

        <label>Industry</label>
        <input type="text" name="industry" required>

        <label>Bio</label>
        <textarea name="bio" rows="4" required></textarea>

        <label>Upload Profile Picture (JPG/PNG)</label>
        <input type="file" name="profile_picture" accept=".jpg, .png" required>

        <label>Upload Certificate (PDF/Image)</label>
        <input type="file" name="certificate" accept=".pdf, .jpg, .png" required>

        <label>Upload Government ID (PDF/Image)</label>
        <input type="file" name="gov_id" accept=".pdf, .jpg, .png" required>

        <label>Motivation (Why do you want to be a mentor?)</label>
        <textarea name="motivation" rows="4" required></textarea>

        <label>Availability (Days & Times)</label>
        <input type="text" name="availability" required>

        <button type="submit">Submit Verification</button>
    </form>
</div>

</body>
</html>
