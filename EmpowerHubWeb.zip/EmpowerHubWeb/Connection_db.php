<?php
$servername = "localhost:3308"; // Change if using a remote server
$username = "root"; // Your MySQL username
$password = ""; // Your MySQL password (leave empty if using XAMPP)
$database = "empowerhub_db"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
