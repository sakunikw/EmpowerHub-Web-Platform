<?php
session_start();
include 'Connection_db.php';

if (isset($_POST['add_mentor'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Secure password

    $sql = "INSERT INTO mentors (username, email, password) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $username, $email, $password);
    
    if ($stmt->execute()) {
        $_SESSION['message'] = "Mentor added successfully!";
    } else {
        $_SESSION['message'] = "Error adding mentor.";
    }
    header("Location: Admin_manage_users.php");
    exit();
}
?>