<?php
include 'Connection_db.php';

if (!isset($_GET['mentor_id'])) {
    die("Mentor ID is missing.");
}

$mentor_id = intval($_GET['mentor_id']);
$sql = "SELECT * FROM mentor_verification WHERE id = $mentor_id";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    die("Mentor not found.");
}

$mentor = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Request Session with <?php echo htmlspecialchars($mentor['full_name']); ?></title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    
    
    <<div class="container">
    <h2>Request a Session with <?php echo htmlspecialchars($mentor['full_name']); ?></h2>
    
    <form action="submit_session_request.php" method="post">
        <input type="hidden" name="mentor_id" value="<?php echo $mentor_id; ?>">

        <label for="user_name">Your Name:</label>
        <input type="text" id="user_name" name="user_name" required>

        <label for="user_email">Your Email:</label>
        <input type="email" id="user_email" name="user_email" required>

        <label for="session_date">Preferred Date:</label>
        <input type="date" id="session_date" name="session_date" required>

        <label for="session_time">Preferred Time:</label>
        <input type="time" id="session_time" name="session_time" required>

        <label for="message">Message (Optional):</label>
        <textarea id="message" name="message" rows="4"></textarea>

        <button type="submit">Request Session</button>
    </form>
</div>


</body>
</html>

<?php $conn->close(); ?>

<style>
    /* General Styling */
body {
    font-family: 'Arial', sans-serif;
    background-color: #f8f9fa;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

/* Form Container */
.container {
    background: white;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    width: 100%;
    max-width: 500px;
    text-align: center;
}

/* Heading */
h2 {
    color: #007bff;
    margin-bottom: 20px;
    font-size: 24px;
}

/* Labels */
label {
    display: block;
    text-align: left;
    font-weight: bold;
    margin-bottom: 5px;
    color: #333;
}

/* Input Fields */
input, textarea {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ddd;
    border-radius: 5px;
    font-size: 16px;
    box-sizing: border-box;
}

/* Focus Styling */
input:focus, textarea:focus {
    border-color: #007bff;
    outline: none;
}

/* Button */
button {
    background-color: #007bff;
    color: white;
    border: none;
    padding: 12px 20px;
    font-size: 16px;
    border-radius: 5px;
    cursor: pointer;
    transition: background 0.3s;
    width: 100%;
}

button:hover {
    background-color: #0056b3;
}

/* Responsive */
@media (max-width: 600px) {
    .container {
        width: 90%;
    }
    h2 {
        font-size: 20px;
    }
}

</style>