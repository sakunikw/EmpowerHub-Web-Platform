<?php
session_start();
include 'Connection_db.php'; // Database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['id'])) {
        $id = $_POST['id'];

        // Prepare statement to prevent SQL injection
        $sql = "DELETE FROM contact_messages WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            echo "<script>alert('Message deleted successfully!'); window.location.href='admin_view_messages.php';</script>";
        } else {
            echo "<script>alert('Error deleting message!'); window.location.href='admin_view_messages.php';</script>";
        }

        $stmt->close();
    }
}

$conn->close();
?>
