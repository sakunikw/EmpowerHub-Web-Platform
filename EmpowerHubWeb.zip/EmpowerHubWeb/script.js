// Get elements
const chatbotIcon = document.getElementById("chatbot-icon");
const chatWindow = document.getElementById("chat-window");
const closeChat = document.getElementById("close-chat");
const chatBody = document.getElementById("chat-body");
const userInput = document.getElementById("chat-input");
const sendBtn = document.getElementById("send-btn");

// Show Chat Window on Click
chatbotIcon.addEventListener("click", () => {
    chatWindow.style.display = "flex";
});

// Close Chat Window
closeChat.addEventListener("click", () => {
    chatWindow.style.display = "none";
});

// Send Message on Button Click
sendBtn.addEventListener("click", sendMessage);

// Send Message on Enter Key Press
userInput.addEventListener("keypress", function(event) {
    if (event.key === "Enter") {
        sendMessage();
    }
});

// Function to Send Message
async function sendMessage() {
    const message = userInput.value.trim();
    if (!message) return;

    appendMessage("You", message);
    userInput.value = "";

    try {
        const response = await fetch("chatbot.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: new URLSearchParams({ message: message }),
        });

        const data = await response.json();
        const botResponse = data.response || "Sorry, I could not process that.";

        appendMessage("Bot", botResponse);
    } catch (error) {
        console.error("Error:", error);
        appendMessage("Bot", "Sorry, I encountered an error.");
    }
}

// Function to Append Messages to Chat
function appendMessage(sender, message) {
    const messageDiv = document.createElement("div");
    messageDiv.classList.add(sender === "You" ? "user-message" : "bot-message");
    messageDiv.innerHTML = `<strong>${sender}:</strong> ${message}`;
    chatBody.appendChild(messageDiv);
    chatBody.scrollTop = chatBody.scrollHeight;
}
