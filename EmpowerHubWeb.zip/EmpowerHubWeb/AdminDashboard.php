<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

include 'Connection_db.php';



if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process approve or reject action
if (isset($_POST['action']) && isset($_POST['mentor_id'])) {
    $mentor_id = $_POST['mentor_id'];
    $status = $_POST['action'] == 'approve' ? 'approved' : 'rejected';
    
    $sql = "UPDATE mentor_verification SET status = ? WHERE mentor_id = ?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("si", $status, $mentor_id);
        if ($stmt->execute()) {
            echo "<script>alert('Mentor verification $status successfully!'); window.location.href='admin_dashboard.php';</script>";
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    }
}

// Fetch pending mentors for approval/rejection
$sql = "SELECT * FROM mentor_verification WHERE status = 'pending'";
$result = $conn->query($sql);

// Fetch statistics for dashboard
$totalMentors = $conn->query("SELECT COUNT(*) AS count FROM mentors")->fetch_assoc()['count'];
$consultationRequests = $conn->query("SELECT COUNT(*) AS count FROM consultation_requests")->fetch_assoc()['count'];
$verifiedMentors = $conn->query("SELECT COUNT(*) AS count FROM mentor_verification WHERE status='approved'")->fetch_assoc()['count'];

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { font-family: Arial, sans-serif; background-color: #f8f9fa; }
        .sidebar { background-color: #343a40; color: white; height: 100vh; position: fixed; width: 250px; padding-top: 20px; }
        .sidebar a { display: block; color: white; padding: 10px 20px; text-decoration: none; margin: 10px 0; }
        .sidebar a:hover { background-color: #495057; }
        .content { margin-left: 260px; padding: 20px; }
        .footer { background-color: #343a40; color: white; text-align: center; padding: 10px; position: fixed; bottom: 0; width: calc(100% - 250px); }
    </style>
</head>
<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <h4 class="text-center">Admin Panel</h4>
        <a href="#">Dashboard</a>
        <a href="Admin_manage_users.php">Manage Users</a>
        <a href="admin_projects.php">Manage Projects</a>
        <a href="#">Settings</a>
        <a href="admin_logout.php" onclick="return confirm('Are you sure you want to logout?');">Logout</a>

    </div>

    <!-- Main Content -->
    <div class="content">
        <nav class="navbar navbar-expand-lg navbar-light bg-light p-3">
            <div class="container-fluid">
                <span class="navbar-brand">Welcome, Admin</span>
            </div>
        </nav>

        <!-- Dashboard Overview -->
        <div class="container mt-4">
            <div class="row">
                <div class="col-md-4">
                    <div class="card text-white bg-primary mb-3">
                        <div class="card-body">
                            <h5 class="card-title">Total Mentors</h5>
                            <p class="card-text"><?php echo $totalMentors; ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-white bg-success mb-3">
                        <div class="card-body">
                            <h5 class="card-title">Consultation Requests</h5>
                            <p class="card-text"><?php echo $consultationRequests; ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-white bg-warning mb-3">
                        <div class="card-body">
                            <h5 class="card-title">Verified Mentors</h5>
                            <p class="card-text"><?php echo $verifiedMentors; ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Mentor Verification Table -->
            <div class="card mt-4">
                <div class="card-header">Pending Mentor Verification</div>
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>LinkedIn</th>
                                <th>Certificate</th>
                                <th>Gov ID</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) { ?>
                                    <tr>
                                        <td><?php echo $row['full_name']; ?></td>
                                        <td><?php echo $row['email']; ?></td>
                                        <td><a href="<?php echo $row['linkedin']; ?>" target="_blank">Profile</a></td>
                                        <td><a href="<?php echo $row['certificate_path']; ?>" target="_blank">View</a></td>
                                        <td><a href="<?php echo $row['gov_id_path']; ?>" target="_blank">View</a></td>
                                        <td>
                                            <form method="POST" style="display:inline;">
                                                <input type="hidden" name="mentor_id" value="<?php echo $row['mentor_id']; ?>">
                                                <button type="submit" name="action" value="approve" class="btn btn-success">Approve</button>
                                            </form>
                                            <form method="POST" style="display:inline;">
                                                <input type="hidden" name="mentor_id" value="<?php echo $row['mentor_id']; ?>">
                                                <button type="submit" name="action" value="reject" class="btn btn-danger">Reject</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php }
                            } else {
                                echo "<tr><td colspan='6'>No pending mentor verification requests.</td></tr>";
                            } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">&copy; 2025 EmpowerHub. All Rights Reserved.</footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>