<?php
session_start();
include 'Connection_db.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $app_id = $_POST['id'];

    $stmt = $conn->prepare("DELETE FROM job_applications WHERE id = ?");
    $stmt->bind_param("i", $app_id);

    if ($stmt->execute()) {
        echo "success";  
    } else {
        echo "error";
    }
}
?>
