<?php
session_start();
require 'connection_db.php'; // Database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if (empty($email) || empty($password)) {
        $_SESSION['error'] = "All fields are required!";
        header("Location: invest_signin.php");
        exit();
    }

    // Check if user exists
    $stmt = $conn->prepare("SELECT id, fullname, password, role FROM users_invest WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows == 1) {
        $stmt->bind_result($id, $fullname, $hashed_password, $role);
        $stmt->fetch();

        if (password_verify($password, $hashed_password)) {
            session_regenerate_id(true); // Prevent session fixation
            $_SESSION['user_id'] = $id;
            $_SESSION['fullname'] = $fullname;
            $_SESSION['email'] = $email; // Corrected variable
            $_SESSION['role'] = $role;
            $_SESSION['success'] = "Welcome, $fullname!";

            // Redirect based on role
            if ($role == "investor") {
                header("Location: investor.php");
            } elseif ($role == "innovator") {
                header("Location: innovator.php");
            } else {
                $_SESSION['error'] = "Invalid role!";
                header("Location: invest_signin.php");
            }
            exit();
        } else {
            $_SESSION['error'] = "Incorrect password!";
        }
    } else {
        $_SESSION['error'] = "No account found with this email!";
    }

    $stmt->close();
    $conn->close();
    header("Location: invest_signin.php");
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - EmpowerHub</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #eef4f6;
            margin: 0;
            padding: 0;
        }

        .navbar {
            background-color: #004d4d;
            padding: 16px 0;
            text-align: center;
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 100;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .navbar a {
            color: #ffffff;
            text-decoration: none;
            font-size: 18px;
            margin: 0 20px;
            font-weight: 600;
            transition: color 0.3s ease;
        }

        .navbar a:hover {
            color: #a7ffeb;
        }

        .hero-image {
            background: linear-gradient(to right, #009688, #004d4d);
            height: 350px;
            margin-top: 80px;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #ffffff;
            font-size: 44px;
            font-weight: 700;
            letter-spacing: 1px;
            text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.4);
        }

        .login-container {
            background: #ffffff;
            padding: 50px 40px;
            border-radius: 12px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            margin: -120px auto 60px auto;
            text-align: center;
        }

        .login-container h2 {
            margin-bottom: 25px;
            color: #333333;
            font-size: 26px;
        }

        input {
            width: 100%;
            padding: 12px 15px;
            margin: 12px 0;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 16px;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }

        input:focus {
            border-color: #009688;
            box-shadow: 0 0 8px rgba(0, 150, 136, 0.2);
            outline: none;
        }

        .btn {
            background-color: #009688;
            color: #ffffff;
            padding: 12px 0;
            border: none;
            border-radius: 6px;
            width: 100%;
            cursor: pointer;
            font-size: 18px;
            font-weight: 600;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #00796b;
        }

        .footer {
            margin-top: 18px;
            font-size: 15px;
            color: #555;
        }

        .footer a {
            color: #009688;
            text-decoration: none;
            font-weight: 600;
        }

        .footer a:hover {
            color: #00796b;
        }

        @media screen and (max-width: 480px) {
            .login-container {
                padding: 40px 25px;
                margin: -100px 20px 40px 20px;
            }

            .hero-image {
                font-size: 32px;
                text-align: center;
                padding: 0 10px;
            }
        }
    </style>
</head>
<body>
    <div class="navbar">
        <a href="index.php">Home</a>
        <a href="about.php">About Us</a>
        <a href="contact.php">Contact</a>
    </div>

    <div class="hero-image">
        Welcome to EmpowerHub
    </div>

    <div class="login-container">
        <h2>Login to EmpowerHub</h2>
        <form action="" method="POST">
            <input type="email" name="email" placeholder="Email Address" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit" class="btn">Login</button>
        </form>
        <p class="footer">Don't have an account? <a href="invest_signup.php">Sign Up Here</a></p>
    </div>
</body>
</html>
