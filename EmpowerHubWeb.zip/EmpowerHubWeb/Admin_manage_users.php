<?php
session_start();
include 'Connection_db.php';

// Handle mentor deletion
if (isset($_POST['delete_mentor'])) {
    $id = $_POST['mentor_id'];
    $sql = "DELETE FROM mentors WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $_SESSION['message'] = "Mentor deleted successfully!";
    header("Location: Admin_manage_users.php");
    exit();
}

// Handle mentee deletion
if (isset($_POST['delete_mentee'])) {
    $id = $_POST['mentee_id'];
    $sql = "DELETE FROM mentees WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $_SESSION['message'] = "Mentee deleted successfully!";
    header("Location: Admin_manage_users.php");
    exit();
}

// Fetch mentors
$sql_mentors = "SELECT * FROM mentors";
$result_mentors = $conn->query($sql_mentors);

// Fetch mentees
$sql_mentees = "SELECT * FROM mentees";
$result_mentees = $conn->query($sql_mentees);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body { font-family: Arial, sans-serif; background-color: #f8f9fa; }
        .sidebar { background-color: #343a40; color: white; height: 100vh; position: fixed; width: 250px; padding-top: 20px; }
        .sidebar a { display: block; color: white; padding: 10px 20px; text-decoration: none; margin: 10px 0; }
        .sidebar a:hover { background-color: #495057; }
        .content { margin-left: 260px; padding: 20px; }
        .footer { background-color: #343a40; color: white; text-align: center; padding: 10px; position: fixed; bottom: 0; width: calc(100% - 250px); }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
        <h4 class="text-center">Admin Panel</h4>
        <a href="AdminDashboard.php">Dashboard</a>
        <a href="Admin_manage_users.php">Users</a>
        <a href="#">Reports</a>
        <a href="#">Settings</a>
        <a href="#">Logout</a>
    </div>

    <!-- Main Content -->
    <div class="content">
        <nav class="navbar navbar-expand-lg navbar-light bg-light p-3">
            <div class="container-fluid">
                <span class="navbar-brand">Welcome, Admin</span>
            </div>
        </nav>

<div class="container mt-4">
    <h2 class="mb-4">Manage Users</h2>

    <?php if (isset($_SESSION['message'])): ?>
        <div class="alert alert-info"><?php echo $_SESSION['message']; unset($_SESSION['message']); ?></div>
    <?php endif; ?>

    <h3>Mentors</h3>
    <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addMentorModal">Add Mentor</button>

    <!-- Add Mentor Modal -->
<div class="modal fade" id="addMentorModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Mentor</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form action="Admin_add_mentor.php" method="POST">
                    <div class="mb-3">
                        <label class="form-label">Name</label>
                        <input type="text" name="username" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" class="form-control" required>
                    </div>
                    <button type="submit" name="add_mentor" class="btn btn-primary">Add Mentor</button>
                </form>
            </div>
        </div>
    </div>
</div>


    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>password</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result_mentors->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['username']; ?></td>
                <td><?php echo $row['email']; ?></td>
                <td><?php echo $row['password']; ?></td>

                
                <td>
                    <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#editMentorModal<?php echo $row['id']; ?>">Edit</button>
                    <form method="POST" class="d-inline">
                        <input type="hidden" name="mentor_id" value="<?php echo $row['id']; ?>">
                        <button type="submit" name="delete_mentor" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</button>
                    </form>
                </td>
            </tr>

            <!-- Edit Mentor Modal -->
            <div class="modal fade" id="editMentorModal<?php echo $row['id']; ?>" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Edit Mentor</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                    <div class="modal-body">
                        <form action="Admin_update_mentor.php" method="POST">
                        <input type="hidden" name="mentor_id" value="<?php echo $row['id']; ?>">
                    <div class="mb-3">
                        <label class="form-label">Name</label>
                        <input type="text" name="username" class="form-control" value="<?php echo $row['username']; ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" value="<?php echo $row['email']; ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" class="form-control" value="<?php echo $row['password']; ?>" required>
                    </div>
                             <button type="submit" name="update_mentor" class="btn btn-primary">Update Mentor</button>
</form>

                        </div>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </tbody>
    </table>

    <h3>Mentees</h3>
    <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addMenteeModal">Add Mentee</button>

    <!-- Add Mentee Modal -->
<div class="modal fade" id="addMenteeModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Mentee</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form action="Admin_add_mentee.php" method="POST">
                    <div class="mb-3">
                        <label class="form-label">Name</label>
                        <input type="text" name="full_name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" class="form-control" required>
                    </div>
                    <button type="submit" name="add_mentee" class="btn btn-primary">Add Mentee</button>
                </form>
            </div>
        </div>
    </div>
</div>


    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>password</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result_mentees->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['full_name']; ?></td>
                <td><?php echo $row['email']; ?></td>
                <td><?php echo $row['password']; ?></td>
                <td>
                    <form method="POST" class="d-inline">
                        <input type="hidden" name="mentee_id" value="<?php echo $row['id']; ?>">
                        <button type="submit" name="delete_mentee" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    
</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>

