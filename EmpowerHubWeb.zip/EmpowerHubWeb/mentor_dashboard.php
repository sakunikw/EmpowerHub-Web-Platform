<?php
session_start();
include 'Connection_db.php';

if (!isset($_SESSION["email"])) { // Use email instead of id
    header("Location: MentorSignIn.php");
    exit();
}

$mentor_email = $_SESSION["email"]; // Get mentor email from session
$sql = "SELECT sr.* FROM session_requests sr 
        JOIN mentor_verification mv ON sr.mentor_email = mv.email
        WHERE mv.email = ? ORDER BY sr.created_at DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $mentor_email);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mentor Dashboard - Session Requests</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h2>Session Requests</h2>
    <table border="1">
        <tr>
            <th>User</th>
            <th>Email</th>
            <th>Date</th>
            <th>Time</th>
            <th>Message</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?php echo htmlspecialchars($row['user_name']); ?></td>
            <td><?php echo htmlspecialchars($row['user_email']); ?></td>
            <td><?php echo $row['session_date']; ?></td>
            <td><?php echo $row['session_time']; ?></td>
            <td><?php echo nl2br(htmlspecialchars($row['message'])); ?></td>
            <td><?php echo $row['status']; ?></td>
            <td>
                <?php if ($row['status'] == 'pending') { ?>
                    <a href="update_request.php?email=<?php echo urlencode($row['mentor_email']); ?>&status=approved">Approve</a> | 
                    <a href="update_request.php?email=<?php echo urlencode($row['mentor_email']); ?>&status=rejected">Reject</a>
                <?php } else { ?>
                    <?php echo ucfirst($row['status']); ?>
                <?php } ?>
            </td>
        </tr>
        <?php } ?>
    </table>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
