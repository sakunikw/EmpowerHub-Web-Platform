<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('Login required'); window.location.href='MentorSignIn.php';</script>";
    exit();
}

$request_id = $_GET['request_id'] ?? '';
$room_id = "MentorshipSession_" . preg_replace('/[^a-zA-Z0-9]/', '', $request_id); // sanitize room name
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Mentorship Live Video Call</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background-color: #f0f2f5;
            font-family: 'Segoe UI', sans-serif;
        }

        .container {
            text-align: center;
            margin-top: 30px;
        }

        h2 {
            font-weight: 600;
            color: #333;
        }

        iframe {
            margin-top: 20px;
            width: 100%;
            height: 600px;
            border: none;
            border-radius: 12px;
            box-shadow: 0 6px 20px rgba(0,0,0,0.15);
        }

        .btn-back {
            margin-top: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Mentorship Live Video Call</h2>
    <p>Consultation Request ID: <strong><?php echo htmlspecialchars($request_id); ?></strong></p>

    <iframe
        src="https://meet.jit.si/<?php echo $room_id; ?>"
        allow="camera; microphone; fullscreen; display-capture"
        allowfullscreen>
    </iframe>

    <a href="mentor_accepted_requests.php" class="btn btn-secondary btn-back">← Back to Approved Requests</a>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
