<?php
include 'Connection_db.php';
$jobId = $_GET['id'];
$stmt = $conn->prepare("SELECT * FROM job_postings WHERE id = ?");
$stmt->bind_param("i", $jobId);
$stmt->execute();
$job = $stmt->get_result()->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title><?= htmlspecialchars($job['title']) ?> - Job Details</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
  <style>
    body {
      background-color: #f8f9fa;
      font-family: 'Segoe UI', sans-serif;
    }
    
    .job-details-container {
      max-width: 800px;
      margin: 50px auto;
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.1);
    }

    .job-header {
      background: linear-gradient(to right, #0d6efd, #6610f2);
      color: white;
      padding: 20px;
      border-radius: 10px 10px 0 0;
      text-align: center;
    }

    .job-info {
      padding: 20px;
    }

    .apply-section {
      padding: 20px;
      border-top: 2px solid #ddd;
    }

    .btn-apply {
      background-color: #0d6efd;
      color: white;
      padding: 10px 15px;
      border-radius: 8px;
      font-weight: 500;
      transition: background-color 0.3s ease;
    }

    .btn-apply:hover {
      background-color: #084298;
    }
  </style>
</head>
<body>

  <div class="container">
    <div class="job-details-container">
      
      <!-- Job Header -->
      <div class="job-header">
        <h2><?= htmlspecialchars($job['title']) ?></h2>
        <p><?= htmlspecialchars($job['location']) ?> | <?= htmlspecialchars($job['category']) ?></p>
      </div>

      <!-- Job Info -->
      <div class="job-info">
        <p><strong>Description:</strong> <?= nl2br(htmlspecialchars($job['description'])) ?></p>
        <p><strong>Salary:</strong> <?= htmlspecialchars($job['salary']) ?></p>
        <p><strong>Job Type:</strong> <?= htmlspecialchars($job['job_type']) ?></p>
      </div>

      <!-- Apply Section -->
      <form action="job_application_submit.php" method="POST" enctype="multipart/form-data">
  <input type="hidden" name="job_id" value="<?= $job['id'] ?>">
  
  <div class="mb-3">
    <label class="form-label">Name</label>
    <input type="text" name="name" class="form-control" required>
  </div>

  <div class="mb-3">
    <label class="form-label">Email</label>
    <input type="email" name="email" class="form-control" required>
  </div>

  <div class="mb-3">
    <label class="form-label">Resume (Upload CV)</label>
    <input type="file" name="cv_file" class="form-control" accept=".pdf,.doc,.docx" required>
  </div>

  <div class="mb-3">
    <label class="form-label">Cover Letter</label>
    <textarea name="cover_letter" class="form-control" required></textarea>
  </div>

  <button type="submit" class="btn btn-apply w-100">Submit Application</button>
</form>


    </div>
  </div>

</body>
</html>
