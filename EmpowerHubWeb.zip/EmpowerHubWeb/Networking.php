<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Networking & Community | EmpowerHub</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f8f9fa;
    }
    .section-title {
      font-size: 2.5rem;
      font-weight: 700;
      color: #212529;
    }
    .card {
      border: none;
      border-radius: 15px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      transition: transform 0.3s ease;
    }
    .card:hover {
      transform: translateY(-5px);
    }
    .icon-circle {
      width: 60px;
      height: 60px;
      background-color: #0d6efd;
      color: white;
      font-size: 1.5rem;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      margin-bottom: 15px;
    }
    .hero-section {
      background: url('images/i3.jpeg') no-repeat center center/cover;
      padding: 80px 20px;
      color: white;
      text-align: center;
    }
    .hero-section h1 {
      font-size: 3rem;
      font-weight: bold;
    }
    .cta-banner {
      background: linear-gradient(135deg, #0d6efd, #6610f2);
      color: white;
      padding: 50px 30px;
      border-radius: 15px;
      text-align: center;
      margin-top: 60px;
    }
    .cta-banner h3 {
      font-size: 2rem;
      font-weight: 600;
    }
  </style>
</head>
<body>

  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">EmpowerHub</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="startups_dashboard.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Services</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Contact</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Hero Section -->
  <div class="hero-section">
    <h1>Networking & Community</h1>
    <p>Connect, collaborate, and grow your business with EmpowerHub's vibrant startup ecosystem.</p>
  </div>

  <div class="container py-5">

    <!-- Core Cards -->
    <div class="row text-center mb-4">
      <h2 class="section-title">Engage, Connect & Grow Together</h2>
    </div>
    <div class="row g-4">

      <div class="col-lg-4 col-md-6">
        <div class="card p-4 h-100">
          <div class="icon-circle mx-auto"><i class="fas fa-comments"></i></div>
          <h5 class="card-title text-center">Business Forums</h5>
          <p class="card-text text-center">Ask questions, share ideas, and get feedback from peers and mentors.</p>
          <div class="text-center">
            <a href="#" class="btn btn-outline-primary">Join Forum</a>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-md-6">
        <div class="card p-4 h-100">
          <div class="icon-circle mx-auto"><i class="fas fa-microphone"></i></div>
          <h5 class="card-title text-center">Events & Webinars</h5>
          <p class="card-text text-center">Attend live webinars & meetups with experts and startup founders.</p>
          <div class="text-center">
            <a href="#" class="btn btn-outline-primary">View Events</a>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-md-6 mx-auto">
        <div class="card p-4 h-100">
          <div class="icon-circle mx-auto"><i class="fas fa-handshake"></i></div>
          <h5 class="card-title text-center">Collaboration Opportunities</h5>
          <p class="card-text text-center">Partner with other startups or join business accelerators.</p>
          <div class="text-center">
            <a href="#" class="btn btn-outline-primary">Explore Partners</a>
          </div>
        </div>
      </div>

    </div>

    <!-- Join the Community Form -->
    <div class="row mt-5">
      <h3 class="text-center mb-4 section-title">Join Our Community</h3>
      <div class="col-md-8 mx-auto">
        <div class="card p-4">
          <form>
            <div class="mb-3">
              <label for="name" class="form-label">Full Name</label>
              <input type="text" class="form-control" id="name" placeholder="Your name">
            </div>
            <div class="mb-3">
              <label for="email" class="form-label">Email Address</label>
              <input type="email" class="form-control" id="email" placeholder="you@example.com">
            </div>
            <div class="mb-3">
              <label for="interest" class="form-label">Area of Interest</label>
              <select class="form-select" id="interest">
                <option value="">-- Select --</option>
                <option>Mentorship</option>
                <option>Collaboration</option>
                <option>Investment Opportunities</option>
                <option>Learning & Resources</option>
              </select>
            </div>
            <div class="text-center">
              <button type="submit" class="btn btn-primary">Join Community</button>
            </div>
          </form>
        </div>
      </div>
    </div>

    <!-- Upcoming Events -->
    <div class="row mt-5">
      <h3 class="text-center mb-4 section-title">Upcoming Events</h3>

      <div class="col-md-4">
        <div class="card">
          <img src="https://source.unsplash.com/400x250/?event,business" class="card-img-top" alt="event1">
          <div class="card-body">
            <h5 class="card-title">Startup Pitch Night</h5>
            <p class="card-text">March 25, 2025 | Colombo</p>
            <a href="#" class="btn btn-outline-primary">Register</a>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="card">
          <img src="https://source.unsplash.com/400x250/?webinar,tech" class="card-img-top" alt="event2">
          <div class="card-body">
            <h5 class="card-title">Digital Marketing Masterclass</h5>
            <p class="card-text">March 30, 2025 | Online</p>
            <a href="#" class="btn btn-outline-primary">Join Webinar</a>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="card">
          <img src="https://source.unsplash.com/400x250/?entrepreneurs,networking" class="card-img-top" alt="event3">
          <div class="card-body">
            <h5 class="card-title">Women in Business Meetup</h5>
            <p class="card-text">April 5, 2025 | Kandy</p>
            <a href="#" class="btn btn-outline-primary">RSVP</a>
          </div>
        </div>
      </div>
    </div>

    <!-- Featured Startups -->
    <div class="row mt-5">
      <h3 class="text-center mb-4 section-title">Featured Community Members</h3>
      <div class="col-md-6">
        <div class="card p-3 mb-3">
          <div class="d-flex align-items-center">
            <img src="https://randomuser.me/api/portraits/men/45.jpg" alt="Founder1" class="rounded-circle me-3" width="60">
            <div>
              <h6 class="mb-1">Ruwan Perera - Founder, SmartAgro</h6>
              <p class="mb-0 small">"I found my first investor and business partner through EmpowerHub!"</p>
            </div>
          </div>
        </div>
      </div>

      <div class="col-md-6">
        <div class="card p-3 mb-3">
          <div class="d-flex align-items-center">
            <img src="https://randomuser.me/api/portraits/women/55.jpg" alt="Founder2" class="rounded-circle me-3" width="60">
            <div>
              <h6 class="mb-1">Nirosha Silva - Co-Founder, BizCraft</h6>
              <p class="mb-0 small">"EmpowerHub webinars gave me the tools to scale faster."</p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Newsletter CTA -->
    <div class="cta-banner mt-5">
      <h3>🚀 Stay Updated with EmpowerHub News</h3>
      <p>Subscribe to our newsletter and never miss networking opportunities or startup events!</p>
      <form class="d-flex justify-content-center mt-3">
        <input type="email" class="form-control w-50 me-2" placeholder="Enter your email">
        <button class="btn btn-light">Subscribe</button>
      </form>
    </div>

  </div>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
