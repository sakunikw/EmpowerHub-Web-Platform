<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'innovator') {
    header("Location: invest_signin.php");
    exit();
}

include "connection_db.php"; // Include your database connection

$innovator_id = $_SESSION['user_id'];
$sql = "SELECT * FROM projects WHERE innovator_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $innovator_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Projects</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 30px;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s;
        }
        .card:hover {
            transform: scale(1.02);
        }
        .status-badge {
            font-size: 14px;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 5px;
        }
        .status-Pending {
            background-color: #ffc107;
            color: #fff;
        }
        .status-Approved {
            background-color: #28a745;
            color: #fff;
        }
        .status-Rejected {
            background-color: #dc3545;
            color: #fff;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">EmpowerHub - My Investments</a>
            <a href="innovator.php" class="btn btn-outline-light">Back to Dashboard</a>
        </div>
    </nav>

<div class="container">
    <h2 class="text-center mb-4">My Submitted Projects</h2>

    <div class="row">
        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="col-md-6 mb-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo htmlspecialchars($row['title']); ?></h5>
                        <h6 class="text-muted"><?php echo htmlspecialchars($row['category']); ?></h6>
                        <p class="card-text"><strong>Budget:</strong> $<?php echo htmlspecialchars($row['budget']); ?></p>
                        <p class="card-text"><strong>Timeline:</strong> <?php echo htmlspecialchars($row['timeline']); ?> days</p>
                        <p class="card-text"><strong>Description:</strong> <?php echo nl2br(htmlspecialchars($row['description'])); ?></p>
                        <p class="card-text"><strong>Innovator:</strong> <?php echo htmlspecialchars($row['innovator_name']); ?></p>
                        <p class="card-text"><strong>Email:</strong> <?php echo htmlspecialchars($row['innovator_email']); ?></p>
                        <p class="card-text"><strong>Contact:</strong> <?php echo htmlspecialchars($row['contact_number']); ?></p>

                        <!-- File download link if available -->
                        <?php if (!empty($row['file_path'])): ?>
                            <p><a href="<?php echo htmlspecialchars($row['file_path']); ?>" target="_blank" class="btn btn-sm btn-primary">Download File</a></p>
                        <?php endif; ?>

                        <span class="status-badge status-<?php echo htmlspecialchars($row['status']); ?>">
                            <?php echo htmlspecialchars($row['status']); ?>
                        </span>
                        
                        <p class="text-muted mt-2"><small>Submitted on: <?php echo htmlspecialchars($row['created_at']); ?></small></p>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>

</body>
</html>
