<?php
session_start();
include 'Connection_db.php';

// Check if the mentor is logged in
if (!isset($_SESSION["mentor_id"])) {
    echo "<script>alert('Please log in first!'); window.location.href='MentorSignIn.php';</script>";
    exit();
}

$mentor_id = $_SESSION["mentor_id"]; // Get mentor's ID from session

// Fetch mentor details (optional, to display mentor name or other details)
$sql = "SELECT * FROM mentor_verification WHERE mentor_id = ?";
if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("i", $mentor_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $mentor = $result->fetch_assoc();
    $stmt->close();
}

// Fetch session requests for this specific mentor
$sql = "SELECT * FROM session_requests WHERE mentor_id = ? ORDER BY created_at DESC";
if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("i", $mentor_id);
    $stmt->execute();
    $requests_result = $stmt->get_result();
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Session Requests - <?php echo htmlspecialchars($mentor['full_name']); ?> | EmpowerHub</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<div class="container">
    <h2>Session Requests for <?php echo htmlspecialchars($mentor['full_name']); ?></h2>

    <?php if ($requests_result->num_rows > 0) { ?>
        <?php while ($request = $requests_result->fetch_assoc()) { ?>
            <div class="session-request">
                <p><strong>User Name:</strong> <?php echo htmlspecialchars($request['user_name']); ?></p>
                <p><strong>Email:</strong> <?php echo htmlspecialchars($request['user_email']); ?></p>
                <p><strong>Preferred Date:</strong> <?php echo htmlspecialchars($request['session_date']); ?></p>
                <p><strong>Preferred Time:</strong> <?php echo htmlspecialchars($request['session_time']); ?></p>
                <p><strong>Message:</strong> <?php echo nl2br(htmlspecialchars($request['message'])); ?></p>
                
                <!-- Form to confirm or reject the request -->
                <form action="update_session_status.php" method="POST">
                    <input type="hidden" name="session_id" value="<?php echo $request['session_id']; ?>">
                    <input type="hidden" name="mentor_id" value="<?php echo $mentor_id; ?>">

                    <label for="status">Confirm or Reject:</label>
                    <select name="status" id="status" required>
                        <option value="confirmed" <?php if ($request['status'] == 'confirmed') echo 'selected'; ?>>Confirm</option>
                        <option value="rejected" <?php if ($request['status'] == 'rejected') echo 'selected'; ?>>Reject</option>
                    </select>
                    
                    <button type="submit">Update Status</button>
                </form>
            </div>
        <?php } ?>
    <?php } else { ?>
        <p>No session requests available at the moment.</p>
    <?php } ?>
</div>

</body>
</html>
