<?php 
session_start(); 
include 'Connection_db.php'; 

// Redirect if not logged in
if (!isset($_SESSION['email']) || empty($_SESSION['email'])) { 
    echo "<script>alert('You need to be logged in to view this page.'); window.location.href='StartupsSignIn.php';</script>"; 
    exit(); 
} 

$mentee_email = $_SESSION['email']; 

// Fetch only approved mentorship requests
$sql = "SELECT cr.*, m.username, m.email AS mentor_email  
        FROM consultation_requests cr 
        JOIN mentors m ON cr.mentor_id = m.id 
        WHERE cr.email = ? AND cr.status = 'Approved'"; 
$stmt = $conn->prepare($sql); 
$stmt->bind_param("s", $mentee_email); 
$stmt->execute(); 
$result = $stmt->get_result(); 

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mentee Dashboard | EmpowerHub</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script src="https://kit.fontawesome.com/your-fontawesome-kit.js" crossorigin="anonymous"></script>
    <style>

body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #ffffff;
    }

    .hero-section {
      padding: 100px 0;
      background: linear-gradient(to right, #fdfdfd, #f6f8fc);
      
      

    }

    .hero-content h1 {
      font-size: 4rem;
      font-weight: 800;
      color: #1f2b3e;
      
     
     
    }

    .hero-content p {
      font-size: 1.2rem;
      color: #4b5563;
      margin-top: 20px;
    }

    .cta-button {
      margin-top: 30px;
      padding: 12px 30px;
      border-radius: 50px;
      font-weight: 600;
    }

    .hero-image {
      width: 100%;
      border-radius: 20px;
      
    }

    .fade-in {
      opacity: 0;
      transform: translateY(30px);
      transition: all 1s ease-in-out;
    }

    .fade-in.show {
      opacity: 1;
      transform: translateY(0);
    }

    @media (max-width: 767px) {
      .hero-content h1 {
        font-size: 2.2rem;
      }
      .hero-content {
        text-align: center;
      }
    }



       
        .dashboard-container {
            margin-top: 50px;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
        }
        .card:hover {
            transform: scale(1.02);
        }
        .mentorship-info {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .mentorship-info h3 {
            color: #007bff;
            font-weight: bold;
        }
        .mentorship-info p, .mentorship-info ul li {
            font-size: 16px;
            color: #555;
        }
        .mentorship-info ul {
            padding-left: 20px;
        }
        .btn-primary {
            width: 100%;
            font-size: 16px;
            font-weight: bold;
            margin-top: 15px;
        }
        .badge {
            font-size: 14px;
        }



        .roadmap-container {
            padding: 50px 0;
        }
        .timeline {
            position: relative;
            max-width: 800px;
            margin: auto;
        }
        .timeline::after {
            content: '';
            position: absolute;
            width: 6px;
            background-color: #007bff;
            top: 0;
            bottom: 0;
            left: 50%;
            margin-left: -3px;
        }
        .timeline-item {
            padding: 20px 40px;
            position: relative;
            background-color: inherit;
            width: 50%;
        }
        .timeline-item.left {
            left: 0;
        }
        .timeline-item.right {
            left: 50%;
        }
        .timeline-item::after {
            content: '';
            position: absolute;
            width: 25px;
            height: 25px;
            right: -12px;
            background-color: white;
            border: 4px solid #007bff;
            top: 15px;
            border-radius: 50%;
            z-index: 1;
        }
        .timeline-item.right::after {
            left: -12px;
        }
        .timeline-content {
            padding: 20px;
            background-color: white;
            position: relative;
            border-radius: 6px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
        }
        .timeline-content:hover {
            transform: scale(1.05);
        }
        .timeline-content h4 {
            color: #007bff;
            font-weight: bold;
        }
        .timeline-content p {
            color: #555;
            margin-bottom: 0;
        }
        .icon {
            font-size: 24px;
            margin-right: 10px;
            color: #007bff;
        }

        .success-stories-section {
      padding: 80px 0;
      background: linear-gradient(to right, #ffffff, #f2f6fc);
    }

    .section-title {
      text-align: center;
      margin-bottom: 60px;
    }

    .section-title h2 {
      font-size: 2.8rem;
      font-weight: 700;
      color: #1f2b3e;
    }

    .testimonial-card {
      background-color: #ffffff;
      border-radius: 20px;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.07);
      padding: 30px;
      transition: transform 0.3s ease;
    }

    .testimonial-card:hover {
      transform: translateY(-8px);
    }

    .testimonial-image {
      width: 80px;
      height: 80px;
      border-radius: 50%;
      object-fit: cover;
      margin-bottom: 15px;
    }

    .testimonial-name {
      font-weight: 600;
      font-size: 1.1rem;
      color: #2c3e50;
    }

    .testimonial-role {
      font-size: 0.95rem;
      color: #6b7280;
      margin-bottom: 15px;
    }

    .testimonial-text {
      font-style: italic;
      color: #4b5563;
    }

    .fade-in {
      opacity: 0;
      transform: translateY(30px);
      transition: all 1s ease-in-out;
    }

    .fade-in.show {
      opacity: 1;
      transform: translateY(0);
    }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="#">EmpowerHub</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link active" href="Networking.php">Networking</a></li>
                <li class="nav-item"><a class="nav-link" href="Mentor_panel.php">Mentors</a></li>
                <li class="nav-item"><a class="nav-link" href="startups_post_vacancy.php">Post Job Vacancies</a></li>
                <li class="nav-item"><a class="nav-link" href="startups_view_job_applicants.php">View Job Applications</a></li>

                <li class="nav-item"><a class="nav-link btn btn-light text-primary" href="startup_logout.php">Logout</a></li>
            </ul>
        </div> 
    </div>
</nav>


<!-- Introduction Section with Image -->
<section class="hero-section">
    <div class="container">
      <div class="row align-items-center">
        <!-- Text Content -->
        <div class="col-lg-6 col-md-12 fade-in" id="introText">
          <div class="hero-content">
            <h1>Empower Your Business Journey</h1>
            <p>
              EmpowerHub helps aspiring entrepreneurs launch their dream businesses with expert guidance, practical tools, and a strong startup community.
            </p>
            <ul class="mt-3 ps-3">
              <li>Personalized mentorship & consulting</li>
              <li>Business planning & financial calculators</li>
              <li>Legal, branding & marketing support</li>
              <li>Network with fellow entrepreneurs</li>
            </ul>
          </div>
        </div>

        <!-- Image -->
        <div class="col-lg-6 col-md-12 text-center mt-4 mt-lg-0 fade-in" id="introImage">
          <img src="images/mentee.png" alt="EmpowerHub Business Start" class="hero-image">
        </div>
      </div>
    </div>
  </section>






<!-- Dashboard Content -->
<div class="container dashboard-container">
    <div class="row">
        <div class="col-md-8">
            <h3>Approved Mentorship Requests</h3>
            <?php 
            if ($result->num_rows > 0) { 
                while ($row = $result->fetch_assoc()) { 
                    // Calculate time left for session
                    $session_date_time = strtotime($row['date'] . ' ' . $row['time']);
                    $time_left = $session_date_time - time();
                    $time_left_text = ($time_left > 0) ? floor($time_left / 3600) . " hrs " . floor(($time_left % 3600) / 60) . " mins left" : "Session Passed";

                    echo "<div class='card p-3 mb-3'>
                            <h5>Mentor: " . htmlspecialchars($row['username']) . "</h5>
                            <p><strong>Email:</strong> " . htmlspecialchars($row['mentor_email']) . "</p>
                            <p><strong>Date:</strong> " . htmlspecialchars($row['date']) . "</p>
                            <p><strong>Time:</strong> " . htmlspecialchars($row['time']) . "</p>
                            <p><strong>Message:</strong> " . nl2br(htmlspecialchars($row['message'])) . "</p>
                            <p><strong>Status:</strong> <span class='badge bg-success'>" . htmlspecialchars($row['status']) . "</span></p>
                            <p><strong>Time Left:</strong> <span class='badge bg-warning text-dark'>$time_left_text</span></p>
                            <button class='btn btn-success' " . ($time_left > 0 ? "" : "disabled") . ">Join Session</button>
                          </div>"; 
                } 
            } else { 
                echo "<p>No approved requests yet.</p>"; 
            } 
            ?>
        </div>

        <div class="col-md-4">
            <div class="mentorship-info">
                <h3>Mentorship Sessions</h3>
                <p>Mentorship sessions at <strong>EmpowerHub</strong> provide valuable guidance for mentees seeking to develop their careers, skills, and personal growth.</p>
                <p><strong>During the sessions, mentees can:</strong></p>
                <ul>
                    <li>Discuss career goals and challenges</li>
                    <li>Receive expert advice on industry trends</li>
                    <li>Develop strategies for personal and professional growth</li>
                    <li>Network and build meaningful professional relationships</li>
                </ul>
                <p>Take the first step towards growth by requesting a session today!</p>
                <a href="mentor_panel.php" class="btn btn-primary">Request a Session</a>
            </div>
        </div>
    </div>
</div>


<!-- Roadmap Section -->
<section class="roadmap-container">
    <div class="container">
        <h2 class="text-center mb-5">Business Growth Roadmap</h2>
        <div class="timeline">
            <!-- Phase 1 -->
            <div class="timeline-item left">
                <div class="timeline-content">
                    <h4><i class="fas fa-lightbulb icon"></i> Idea & Planning</h4>
                    <p>Identify a business idea, conduct market research, and define a business model.</p>
                </div>
            </div>

            <!-- Phase 2 -->
            <div class="timeline-item right">
                <div class="timeline-content">
                    <h4><i class="fas fa-file-contract icon"></i> Legal & Financial Setup</h4>
                    <p>Register your business, set up a bank account, and arrange funding.</p>
                </div>
            </div>

            <!-- Phase 3 -->
            <div class="timeline-item left">
                <div class="timeline-content">
                    <h4><i class="fas fa-cogs icon"></i> Product Development</h4>
                    <p>Develop an MVP, test, iterate, and finalize pricing strategies.</p>
                </div>
            </div>

            <!-- Phase 4 -->
            <div class="timeline-item right">
                <div class="timeline-content">
                    <h4><i class="fas fa-rocket icon"></i> Business Launch</h4>
                    <p>Build a website, market your business, and acquire first customers.</p>
                </div>
            </div>

            <!-- Phase 5 -->
            <div class="timeline-item left">
                <div class="timeline-content">
                    <h4><i class="fas fa-chart-line icon"></i> Growth & Expansion</h4>
                    <p>Scale operations, optimize processes, and innovate for sustainability.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="success-stories-section">
    <div class="container">
      <div class="section-title fade-in">
        <h2>💬 Success Stories</h2>
        <p class="text-muted">Real stories from mentees who started strong with EmpowerHub.</p>
      </div>

      <div class="row g-4">
        <!-- Story 1 -->
        <div class="col-lg-4 col-md-6 fade-in">
          <div class="testimonial-card text-center p-4">
            <img src="https://randomuser.me/api/portraits/women/44.jpg" alt="Mentor 1" class="testimonial-image">
            <div class="testimonial-name">Tharushi Fernando</div>
            <div class="testimonial-role">Founder, TeaBloom Co.</div>
            <p class="testimonial-text">"EmpowerHub gave me the confidence and structure I needed. From my first mentor call to launching my business, it was life-changing!"</p>
          </div>
        </div>

        <!-- Story 2 -->
        <div class="col-lg-4 col-md-6 fade-in">
          <div class="testimonial-card text-center p-4">
            <img src="https://randomuser.me/api/portraits/men/32.jpg" alt="Mentor 2" class="testimonial-image">
            <div class="testimonial-name">Nuwan Silva</div>
            <div class="testimonial-role">CEO, DigiMarket Solutions</div>
            <p class="testimonial-text">"From financial planning tools to mentorship, EmpowerHub guided me every step. My startup scaled faster than expected!"</p>
          </div>
        </div>

        <!-- Story 3 -->
        <div class="col-lg-4 col-md-6 fade-in">
          <div class="testimonial-card text-center p-4">
            <img src="https://randomuser.me/api/portraits/women/68.jpg" alt="Mentor 3" class="testimonial-image">
            <div class="testimonial-name">Ishara Perera</div>
            <div class="testimonial-role">Owner, CraftyNest Studio</div>
            <p class="testimonial-text">"I was overwhelmed at first. But the roadmap, mentorship and community support made my dream business a reality."</p>
          </div>
        </div>
      </div>
    </div>
  </section>



</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>


<script>
       // Fade-in on scroll
    window.addEventListener('scroll', () => {
      const elements = document.querySelectorAll('.fade-in');
      elements.forEach(el => {
        const position = el.getBoundingClientRect().top;
        const screenPosition = window.innerHeight / 1.2;
        if (position < screenPosition) {
          el.classList.add('show');
        }
      });
    });

    // Trigger initial animation on page load
    window.addEventListener('DOMContentLoaded', () => {
      document.querySelectorAll('.fade-in').forEach(el => el.classList.add('show'));
    });

   

    // Show elements on load
    window.addEventListener('DOMContentLoaded', () => {
      document.querySelectorAll('.fade-in').forEach(el => el.classList.add('show'));
    });
</script>
</html>
