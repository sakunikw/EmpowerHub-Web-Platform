<?php
session_start();
include 'Connection_db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $job_id = $_POST['job_id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $cover_letter = $_POST['cover_letter'];

    // File upload handling
    $targetDir = "uploads/cv/";
    if (!file_exists($targetDir)) {
        mkdir($targetDir, 0777, true);
    }

    $fileName = basename($_FILES["cv_file"]["name"]);
    $filePath = $targetDir . time() . "_" . $fileName; // Add timestamp to avoid duplicates
    $fileType = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));

    // Validate file type
    $allowedTypes = ["pdf", "doc", "docx"];
    if (!in_array($fileType, $allowedTypes)) {
        die("Invalid file type. Only PDF, DOC, and DOCX files are allowed.");
    }

    // Move file to server
    if (move_uploaded_file($_FILES["cv_file"]["tmp_name"], $filePath)) {
        // Insert application into the database
        $stmt = $conn->prepare("INSERT INTO job_applications (job_id, applicant_name, applicant_email, cover_letter, cv_file) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("issss", $job_id, $name, $email, $cover_letter, $filePath);

        if ($stmt->execute()) {
            echo "Application submitted successfully.";
        } else {
            echo "Error submitting application.";
        }
    } else {
        echo "Error uploading file.";
    }
}
?>
