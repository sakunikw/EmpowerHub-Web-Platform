<?php
// Include database connection
include 'Connection_db.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Simple validation
    if (empty($full_name) || empty($email) || empty($password) || empty($confirm_password)) {
        $error = "All fields are required!";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match!";
    } else {
        // Hash the password for security
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Check if the email already exists
        $sql = "SELECT * FROM mentees WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $error = "Email is already registered!";
        } else {
            // Insert the new mentee into the database
            $sql = "INSERT INTO mentees (full_name, email, password) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sss", $full_name, $email, $hashed_password);
            if ($stmt->execute()) {
                $success = "Registered successfully! You can now sign in.";
            } else {
                $error = "Error during registration. Please try again.";
            }
        }
    }
}
?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - EmpowerHub</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: rgb(81, 79, 108);
        }
        .container {
            display: flex;
            width: 80%;
            max-width: 1200px;
            background: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }
        .left-panel {
            flex: 1;
            background: url('images/img2.jpg') no-repeat center center/cover;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            padding: 20px;
        }
        .right-panel {
            flex: 1;
            padding: 40px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .logo img {
            width: 450px;
        }
        h2 {
            margin-bottom: 20px;
        }
        form {
            width: 100%;
            display: flex;
            flex-direction: column;
        }
        input {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .register-btn {
            padding: 10px;
            background: #000;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .links {
            margin-top: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .links a {
            color: #000;
            text-decoration: none;
            margin: 8px 0;
            font-weight: bold;
            font-size: 14px;
            transition: color 0.3s;
            display: flex;
            align-items: center;
        }
        .links a:hover {
            color: #6a5acd;
            text-decoration: underline;
        }
        .links a i {
            margin-right: 8px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="left-panel">
            <h1>Welcome to EmpowerHub - Investor Pool</h1>
        </div>
        <div class="right-panel">
            <div class="logo">
                <img src="images/logo.png" alt="EmpowerHub Logo">
            </div>
            <h2>Register for EmpowerHub: Connect, Learn, Grow</h2>

            <?php if (isset($error)) { echo "<p class='error'>$error</p>"; } ?>
    <?php if (isset($success)) { echo "<p class='success'>$success</p>"; } ?>

            <!-- Sign-up Form -->
            <form action="StartupsSignUp.php" method="POST">
        <label for="full_name">Full Name:</label>
        <input type="text" name="full_name" id="full_name" required>

        <label for="email">Email:</label>
        <input type="email" name="email" id="email" required>

        <label for="password">Password:</label>
        <input type="password" name="password" id="password" required>

        <label for="confirm_password">Confirm Password:</label>
        <input type="password" name="confirm_password" id="confirm_password" required>

        <button type="submit">Sign Up</button>
    </form>

            <!-- Links for login or home page -->
            <div class="links">
                <a href="StartupsSignIn.php"><i class="fas fa-user-check"></i> Already registered? Sign in</a>
                <a href="Index.php"><i class="fas fa-home"></i> Back to Home</a>
            </div>
        </div>
    </div>
</body>
</html>
