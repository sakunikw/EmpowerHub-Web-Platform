<?php
session_start();
require 'connection_db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullname = trim($_POST['fullname']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $role = $_POST['role'];

    if (empty($fullname) || empty($email) || empty($password) || empty($confirm_password) || empty($role)) {
        $_SESSION['error'] = "All fields are required!";
        header("Location: invest_signup.php");
        exit();
    }

    if ($password !== $confirm_password) {
        $_SESSION['error'] = "Passwords do not match!";
        header("Location: invest_signup.php");
        exit();
    }

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $conn->prepare("SELECT id FROM users_invest WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $_SESSION['error'] = "Email is already registered!";
        header("Location: invest_signup.php");
        exit();
    }
    $stmt->close();

    $stmt = $conn->prepare("INSERT INTO users_invest (fullname, email, password, role) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $fullname, $email, $hashed_password, $role);

    if ($stmt->execute()) {
        $_SESSION['success'] = "Registration successful! Please login.";
        header("Location: invest_signin.php");
    } else {
        $_SESSION['error'] = "Something went wrong. Try again!";
        header("Location: invest_signup.php");
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - EmpowerHub</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #eef4f6;
            margin: 0;
            padding: 0;
        }

        .navbar {
            background-color: #004d4d;
            padding: 16px 0;
            text-align: center;
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 100;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .navbar a {
            color: #ffffff;
            text-decoration: none;
            font-size: 18px;
            margin: 0 20px;
            font-weight: 600;
            transition: color 0.3s ease;
        }

        .navbar a:hover {
            color: #a7ffeb;
        }

        .hero-image {
            background: linear-gradient(to right, #009688, #004d4d);
            height: 350px;
            margin-top: 80px;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #ffffff;
            font-size: 44px;
            font-weight: 700;
            letter-spacing: 1px;
            text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.4);
        }

        .signup-container {
            background: #ffffff;
            padding: 50px 40px;
            border-radius: 12px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            margin: -120px auto 60px auto;
            text-align: center;
        }

        .signup-container h2 {
            margin-bottom: 25px;
            color: #333333;
            font-size: 26px;
        }

        input, select {
            width: 100%;
            padding: 12px 15px;
            margin: 12px 0;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 16px;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }

        input:focus, select:focus {
            border-color: #009688;
            box-shadow: 0 0 8px rgba(0, 150, 136, 0.2);
            outline: none;
        }

        .btn {
            background-color: #009688;
            color: #ffffff;
            padding: 12px 0;
            border: none;
            border-radius: 6px;
            width: 100%;
            cursor: pointer;
            font-size: 18px;
            font-weight: 600;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #00796b;
        }

        .footer {
            margin-top: 18px;
            font-size: 15px;
            color: #555;
        }

        .footer a {
            color: #009688;
            text-decoration: none;
            font-weight: 600;
        }

        .footer a:hover {
            color: #00796b;
        }

        @media screen and (max-width: 480px) {
            .signup-container {
                padding: 40px 25px;
                margin: -100px 20px 40px 20px;
            }

            .hero-image {
                font-size: 32px;
                text-align: center;
                padding: 0 10px;
            }
        }
    </style>
</head>
<body>
    <div class="navbar">
        <a href="index.php">Home</a>
        <a href="about.php">About Us</a>
        <a href="contact.php">Contact</a>
    </div>

    <div class="hero-image">
        Join EmpowerHub Today
    </div>

    <div class="signup-container">
        <h2>Create Your Account</h2>
        <form action="" method="POST">
            <input type="text" name="fullname" placeholder="Full Name" required>
            <input type="email" name="email" placeholder="Email Address" required>
            <input type="password" name="password" placeholder="Password" required>
            <input type="password" name="confirm_password" placeholder="Confirm Password" required>
            <select name="role" required>
                <option value="" disabled selected>Select Role</option>
                <option value="investor">Investor</option>
                <option value="innovator">Innovator</option>
            </select>
            <button type="submit" class="btn">Sign Up</button>
        </form>
        <p class="footer">Already have an account? <a href="invest_signin.php">Login Here</a></p>
    </div>
</body>
</html>
