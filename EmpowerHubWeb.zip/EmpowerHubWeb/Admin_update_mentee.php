<?php
session_start();
include 'Connection_db.php';

if (isset($_POST['update_mentee'])) {
    $id = $_POST['mentee_id'];
    $name = $_POST['full_name'];
    $email = $_POST['email'];
    $password = $_POST['password']; // Ideally, hash passwords before storing them

    $sql = "UPDATE mentees SET full_name = ?, email = ?, password = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssi", $name, $email, $password, $id);

    if ($stmt->execute()) {
        $_SESSION['message'] = "Mentee updated successfully!";
    } else {
        $_SESSION['message'] = "Error updating mentee.";
    }

    header("Location: Admin_manage_users.php");
    exit();
}
?>
