<?php
include 'Connection_db.php';

// Assuming you have a session-based login system and mentor's id is stored in session
session_start();

// Check if the user is logged in and is a mentor
if (!isset($_SESSION['mentor_id']) || empty($_SESSION['mentor_id'])) {
    die("You need to be logged in as a mentor to view requests.");
}

$mentor_id = $_SESSION['mentor_id']; // Get mentor id from session

// Fetch mentor details
$sql = "SELECT * FROM mentor_verification WHERE mentor_id = ? AND status = 'approved'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $mentor_id);
$stmt->execute();
$result = $stmt->get_result();
$mentor = $result->fetch_assoc();

if (!$mentor) {
    die("Mentor not found or not approved.");
}

// Fetch pending consultation requests for this mentor
$request_sql = "SELECT * FROM consultation_requests WHERE mentor_id = ? AND status = 'pending'";
$request_stmt = $conn->prepare($request_sql);
$request_stmt->bind_param("i", $mentor_id);
$request_stmt->execute();
$request_result = $request_stmt->get_result();

$stmt->close();
$request_stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mentor Dashboard - <?php echo htmlspecialchars($mentor['full_name']); ?></title>
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Basic styles for the mentor dashboard */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }
        .container {
            max-width: 900px;
            margin: 50px auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        .request {
            border-bottom: 1px solid #ddd;
            padding: 15px 0;
        }
        .request p {
            margin: 5px 0;
        }
        .request .status {
            color: #ff5722;
            font-weight: bold;
        }
        .btn-approve, .btn-reject {
            background-color: #28a745;
            color: white;
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin: 5px;
        }
        .btn-approve:hover {
            background-color: #218838;
        }
        .btn-reject {
            background-color: #dc3545;
        }
        .btn-reject:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Pending Consultation Requests for <?php echo htmlspecialchars($mentor['full_name']); ?></h2>

    <?php if ($request_result->num_rows > 0): ?>
        <?php while ($row = $request_result->fetch_assoc()): ?>
            <div class="request">
                <p><strong>Name:</strong> <?php echo htmlspecialchars($row['name']); ?></p>
                <p><strong>Email:</strong> <?php echo htmlspecialchars($row['email']); ?></p>
                <p><strong>Preferred Date:</strong> <?php echo htmlspecialchars($row['date']); ?></p>
                <p><strong>Preferred Time:</strong> <?php echo htmlspecialchars($row['time']); ?></p>
                <p><strong>Message:</strong> <?php echo htmlspecialchars($row['message']); ?></p>
                <p class="status">Status: Pending</p>

                <!-- Approve/Reject buttons (can be implemented with a simple form or through links) -->
                <form action="process_request_status.php" method="POST">
                    <input type="hidden" name="request_id" value="<?php echo $row['id']; ?>">
                    <input type="hidden" name="mentor_id" value="<?php echo $mentor_id; ?>">
                    <button type="submit" name="action" value="approve" class="btn-approve">Approve</button>
                    <button type="submit" name="action" value="reject" class="btn-reject">Reject</button>
                </form>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p>No pending requests found.</p>
    <?php endif; ?>
</div>

</body>
</html>
