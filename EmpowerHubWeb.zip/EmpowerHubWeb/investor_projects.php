<?php
include "connection_db.php"; // Include your database connection

$sql = "SELECT * FROM projects WHERE status = 'Approved'";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Investor Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">EmpowerHub - My Investments</a>
            <a href="investor.php" class="btn btn-outline-light">Back to Dashboard</a>
        </div>
    </nav>
    
    <div class="container mt-5">
        <h2 class="mb-4">Investment Opportunities</h2>

        <div class="row">
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="col-md-4">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($row['title']); ?></h5>
                            <p class="card-text"><strong>Category:</strong> <?php echo htmlspecialchars($row['category']); ?></p>
                            <p class="card-text"><strong>Budget:</strong> $<?php echo htmlspecialchars($row['budget']); ?></p>
                            <p class="card-text"><strong>Timeline:</strong> <?php echo htmlspecialchars($row['timeline']); ?> months</p>
                            <p class="card-text"><strong>Innovator:</strong> <?php echo htmlspecialchars($row['innovator_name']); ?></p>
                            <p class="card-text"><strong>Contact:</strong> <?php echo htmlspecialchars($row['contact_number']); ?></p>
                            <p class="card-text"><?php echo htmlspecialchars($row['description']); ?></p>

                            <?php if (!empty($row['file_path'])): ?>
                                <a href="<?php echo htmlspecialchars($row['file_path']); ?>" download class="btn btn-success btn-sm">Download File</a>
                            <?php else: ?>
                                <p class="text-muted">No file available</p>
                            <?php endif; ?>

                            <a href="invest.php?project_id=<?php echo $row['id']; ?>" class="btn btn-primary btn-sm mt-2">Invest</a>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
</body>
</html>
