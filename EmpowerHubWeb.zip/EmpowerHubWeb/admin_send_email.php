<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $to = $_POST['email'];
    $name = $_POST['name'];
    $subject = "Response from EmpowerHub Admin";
    $message = "Hello $name,\n\nThank you for contacting us. We will get back to you soon.\n\nBest regards,\nEmpowerHub Team";
    $headers = "From: ksakuniweerasinghe@gmail.com"; // Change to your admin email

    if (mail($to, $subject, $message, $headers)) {
        echo "<script>alert('Email sent successfully!'); window.location.href='admin_view_messages.php';</script>";
    } else {
        echo "<script>alert('Failed to send email.'); window.location.href='admin_view_messages.php';</script>";
    }
} else {
    echo "Invalid request.";
}
?>
