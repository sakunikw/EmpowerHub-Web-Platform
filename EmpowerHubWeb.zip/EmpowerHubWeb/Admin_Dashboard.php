<?php
include 'Connection_db.php';

if (isset($_POST['action']) && isset($_POST['mentor_id'])) {
    $mentor_id = $_POST['mentor_id'];
    $status = $_POST['action'] == 'approve' ? 'approved' : 'rejected';
    
    $sql = "UPDATE mentor_verification SET status = ? WHERE id = ?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("si", $status, $mentor_id);
        if ($stmt->execute()) {
            echo "<script>alert('Mentor verification $status successfully!'); window.location.href='admin_dashboard.php';</script>";
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    }
}

$sql = "SELECT * FROM mentor_verification WHERE status = 'pending'";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }
        .container { max-width: 800px; background: white; padding: 20px; border-radius: 8px; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1); margin: auto; }
        h2 { text-align: center; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        th { background: #007bff; color: white; }
        .btn { padding: 8px 12px; margin: 5px; border: none; cursor: pointer; }
        .approve { background: #28a745; color: white; }
        .reject { background: #dc3545; color: white; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Admin Dashboard - Mentor Verification</h2>
        <table>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>LinkedIn</th>
                <th>Certificate</th>
                <th>Gov ID</th>
                <th>Action</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row['full_name']; ?></td>
                    <td><?php echo $row['email']; ?></td>
                    <td><a href="<?php echo $row['linkedin']; ?>" target="_blank">Profile</a></td>
                    <td><a href="<?php echo $row['certificate_path']; ?>" target="_blank">View</a></td>
                    <td><a href="<?php echo $row['gov_id_path']; ?>" target="_blank">View</a></td>
                    <td>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="mentor_id" value="<?php echo $row['id']; ?>">
                            <button type="submit" name="action" value="approve" class="btn approve">Approve</button>
                        </form>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="mentor_id" value="<?php echo $row['id']; ?>">
                            <button type="submit" name="action" value="reject" class="btn reject">Reject</button>
                        </form>
                    </td>
                </tr>
            <?php } ?>
        </table>
    </div>
</body>
</html>
<?php $conn->close(); ?>
