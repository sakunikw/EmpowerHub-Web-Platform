<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'innovator') {
    header("Location: invest_signin.php");
    exit();
}

include "connection_db.php"; // Include your database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $innovator_id = $_SESSION['user_id'];
    $innovator_name = $_SESSION['fullname'];
    $innovator_email = $_SESSION['email'];
    $contact_number = $_POST['contact_number'];
    $title = $_POST['title'];
    $description = $_POST['description'];
    $category = $_POST['category'];
    $budget = $_POST['budget'];
    $timeline = $_POST['timeline'];
    $status = 'Pending';

    // File Upload Handling
    $file_path = "";
    if (!empty($_FILES["project_file"]["name"])) {
        $target_dir = "uploads/";
        $file_path = $target_dir . basename($_FILES["project_file"]["name"]);
        move_uploaded_file($_FILES["project_file"]["tmp_name"], $file_path);
    }

    // Insert into database
    $sql = "INSERT INTO projects (innovator_id, innovator_name, innovator_email, contact_number, title, description, category, budget, timeline, file_path, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("issssssddss", $innovator_id, $innovator_name, $innovator_email, $contact_number, $title, $description, $category, $budget, $timeline, $file_path, $status);

    if ($stmt->execute()) {
        echo "<script>alert('Project submitted successfully! Pending approval.'); window.location.href='innovator.php';</script>";
    } else {
        echo "<script>alert('Error submitting project.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Project</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">EmpowerHub - My Investments</a>
            <a href="innovator.php" class="btn btn-outline-light">Back to Dashboard</a>
        </div>
    </nav>

    <div class="container mt-5">
        <h2>Submit Your Project</h2>
        <form method="post" enctype="multipart/form-data">
            <div class="mb-3">
                <label class="form-label">Contact Number:</label>
                <input type="text" name="contact_number" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Project Title:</label>
                <input type="text" name="title" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Description:</label>
                <textarea name="description" class="form-control" required></textarea>
            </div>
            <div class="mb-3">
                <label class="form-label">Category:</label>
                <select name="category" class="form-control" required>
                    <option value="Tech">Tech</option>
                    <option value="Agriculture">Agriculture</option>
                    <option value="Healthcare">Healthcare</option>
                    <option value="Education">Education</option>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Budget (in USD):</label>
                <input type="number" step="0.01" name="budget" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Timeline (in months):</label>
                <input type="number" name="timeline" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Upload Supporting File (optional):</label>
                <input type="file" name="project_file" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary">Submit Project</button>
        </form>
    </div>
</body>
</html>
