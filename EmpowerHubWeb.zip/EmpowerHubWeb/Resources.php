<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Legal & Registration Assistance | EmpowerHub</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f8f9fc;
      scroll-behavior: smooth;
    }
    .section-title h2 {
      font-size: 2.5rem;
      font-weight: bold;
      color: #1a2c45;
    }
    .icon-box {
      background: white;
      border-radius: 16px;
      box-shadow: 0 6px 18px rgba(0, 0, 0, 0.08);
      padding: 30px;
      transition: 0.3s ease-in-out;
    }
    .icon-box:hover {
      transform: translateY(-6px);
    }
    .icon-box i {
      font-size: 2.5rem;
      color: #004080;
      margin-bottom: 20px;
    }
    .btn-learn {
      background-color: #004080;
      color: white;
      border-radius: 30px;
    }
    .btn-learn:hover {
      background-color: #002c5f;
    }
    .legal-banner {
      background: url('images/i3.jpeg') center/cover no-repeat;
      height: 300px;
      border-radius: 20px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      margin-bottom: 50px;
      text-shadow: 0 2px 5px rgba(0, 0, 0, 0.4);
    }
    .legal-banner h1 {
      font-size: 3.8rem;
      font-weight: bold;
      
    }
    .faq-section .accordion-button {
      font-weight: 500;
    }
    .table thead {
      background-color: #004080;
      color: white;
    }
    .cta-box {
      background-color: #004080;
      color: white;
      padding: 40px;
      border-radius: 15px;
      margin-top: 60px;
      text-align: center;
    }
  </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="Index.php">EmpowerHub</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Mentors</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Contact</a></li>
            </ul>
        </div>
    </div>
</nav>


<div class="container my-5">
  <!-- 📸 Banner -->
  <div class="legal-banner">
    <h1>Legal & Registration Assistance</h1>
  </div>

  <!-- Title -->
  <div class="section-title text-center mb-5">
    <h2><i class="fas fa-briefcase me-2"></i>Your Legal Startup Guide</h2>
    <p class="text-muted">Everything you need to legally start and run your business in Sri Lanka.</p>
  </div>

  <!-- Icon Boxes -->
  <div class="row g-4 mb-5">
    <div class="col-md-4">
      <div class="icon-box text-center p-4">
        <i class="fas fa-file-signature"></i>
        <h5 class="mt-3">📝 Business Registration</h5>
        <p>Follow our guide to register your business with the Registrar of Companies.</p>
        <a href="https://www.drc.gov.lk" class="btn btn-learn mt-3" target="_blank">Official Site</a>
      </div>
    </div>
    <div class="col-md-4">
      <div class="icon-box text-center p-4">
        <i class="fas fa-scale-balanced"></i>
        <h5 class="mt-3">📚 Tax & Compliance</h5>
        <p>Understand VAT, income tax, and reporting duties for your business.</p>
        <a href="https://ird.gov.lk" class="btn btn-learn mt-3" target="_blank">Learn More</a>
      </div>
    </div>
    <div class="col-md-4">
      <div class="icon-box text-center p-4">
        <i class="fas fa-user-shield"></i>
        <h5 class="mt-3">⚖️ Free Legal Help</h5>
        <p>Access legal experts for startup advice. Limited slots available.</p>
        <a href="#book-consultation" class="btn btn-learn mt-3">Book Now</a>
      </div>
    </div>
  </div>

  <!-- 📥 Download Section -->
  <div class="mb-5">
    <h4><i class="fas fa-download me-2"></i>Download Legal Templates & Forms</h4>
    <ul class="list-group">
      <li class="list-group-item">
        <i class="fas fa-file-pdf text-danger me-2"></i>
        <a href="#" download>Business Registration Form (PDF)</a>
      </li>
      <li class="list-group-item">
        <i class="fas fa-file-pdf text-danger me-2"></i>
        <a href="#" download>Tax Compliance Checklist</a>
      </li>
      <li class="list-group-item">
        <i class="fas fa-file-pdf text-danger me-2"></i>
        <a href="#" download>Partnership Agreement Template</a>
      </li>
    </ul>
  </div>

  <!-- 🎥 Video Section -->
  <div class="mb-5">
    <h4><i class="fas fa-video me-2"></i>Video: How to Register a Business in Sri Lanka</h4>
    <div class="ratio ratio-16x9">
      <iframe src="https://www.youtube.com/embed/Zh1ZKHYkkdY" title="Registration Guide" allowfullscreen></iframe>
    </div>
  </div>

  <!-- 📊 Business Types Table -->
  <div class="mb-5">
    <h4><i class="fas fa-table me-2"></i>Compare Business Types in Sri Lanka</h4>
    <div class="table-responsive">
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>Type</th>
            <th>Registration Cost</th>
            <th>Tax Requirement</th>
            <th>Ideal For</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Sole Proprietorship</td>
            <td>Low</td>
            <td>Income Tax</td>
            <td>Freelancers, Small Traders</td>
          </tr>
          <tr>
            <td>Partnership</td>
            <td>Medium</td>
            <td>Partnership Tax</td>
            <td>Family Businesses</td>
          </tr>
          <tr>
            <td>Limited Company</td>
            <td>High</td>
            <td>Corporate Tax, VAT</td>
            <td>Growing Startups, Investors</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>

  <!-- 🙋 FAQ Section -->
  <div class="faq-section mb-5">
    <h4><i class="fas fa-question-circle me-2"></i>Frequently Asked Questions</h4>
    <div class="accordion" id="faqAccordion">
      <div class="accordion-item">
        <h2 class="accordion-header" id="faq1">
          <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapse1">
            What’s the first step in business registration?
          </button>
        </h2>
        <div id="collapse1" class="accordion-collapse collapse show" data-bs-parent="#faqAccordion">
          <div class="accordion-body">
            You must choose a business name and register it via the Department of Registrar of Companies.
          </div>
        </div>
      </div>
      <div class="accordion-item">
        <h2 class="accordion-header" id="faq2">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse2">
            Do I need a lawyer to start a business?
          </button>
        </h2>
        <div id="collapse2" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
          <div class="accordion-body">
            It's not mandatory, but legal advice is recommended to ensure proper documentation and compliance.
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- 🗓️ Booking Form -->
  <div class="mt-5" id="book-consultation">
    <h4 class="mb-3"><i class="fas fa-calendar-alt me-2"></i>Book a Legal Consultation</h4>
    <form class="row g-3">
      <div class="col-md-6">
        <label class="form-label">Full Name</label>
        <input type="text" class="form-control" placeholder="Your Name">
      </div>
      <div class="col-md-6">
        <label class="form-label">Email Address</label>
        <input type="email" class="form-control" placeholder="you@example.com">
      </div>
      <div class="col-md-6">
        <label class="form-label">Preferred Date</label>
        <input type="date" class="form-control">
      </div>
      <div class="col-md-6">
        <label class="form-label">Your Query</label>
        <textarea class="form-control" rows="3"></textarea>
      </div>
      <div class="col-12">
        <button type="submit" class="btn btn-learn px-4">Submit Request</button>
      </div>
    </form>
  </div>

  <!-- 🎯 Call to Action -->
  <div class="cta-box mt-5">
    <h3>Still Have Questions?</h3>
    <p>Our legal experts are ready to assist your business journey.</p>
    <a href="#book-consultation" class="btn btn-light">Get Legal Help Now</a>
  </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<!-- Live Chat Bot (Tawk.to) -->
<script type="text/javascript">
  var Tawk_API = Tawk_API || {}, Tawk_LoadStart = new Date();
  (function(){
    var s1 = document.createElement("script"),s0 = document.getElementsByTagName("script")[0];
    s1.async = true;
    s1.src = 'https://embed.tawk.to/65f01e71a0c6737bd1226c8b/1hpijq6qv'; // Replace this with your unique code
    s1.charset = 'UTF-8';
    s1.setAttribute('crossorigin','*');
    s0.parentNode.insertBefore(s1,s0);
  })();
</script>

</body>
</html>
