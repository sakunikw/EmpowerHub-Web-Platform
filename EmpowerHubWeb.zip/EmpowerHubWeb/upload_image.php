<?php
include 'Connection_db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $mentor_id = $_POST['mentor_id'];
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["profile_picture"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check if file is an actual image
    $check = getimagesize($_FILES["profile_picture"]["tmp_name"]);
    if ($check === false) {
        echo "File is not an image.";
        $uploadOk = 0;
    }

    // Allow only JPG, PNG, and JPEG
    if (!in_array($imageFileType, ['jpg', 'jpeg', 'png'])) {
        echo "Only JPG, JPEG, and PNG files are allowed.";
        $uploadOk = 0;
    }

    // Move file to uploads folder
    if ($uploadOk && move_uploaded_file($_FILES["profile_picture"]["tmp_name"], $target_file)) {
        // Update database with file path
        $sql = "UPDATE mentor_verification SET profile_picture='$target_file' WHERE id='$mentor_id'";
        if ($conn->query($sql) === TRUE) {
            echo "Profile picture uploaded successfully!";
        } else {
            echo "Error updating database: " . $conn->error;
        }
    } else {
        echo "Error uploading file.";
    }

    $conn->close();
}
?>
