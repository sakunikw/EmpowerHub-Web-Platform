<?php
header("Content-Type: application/json");
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Fetch user input
$data = json_decode(file_get_contents("php://input"), true);
if (!$data || !isset($data["preferences"])) {
    echo json_encode(["error" => "Invalid input data"]);
    exit;
}

$preferences = $data["preferences"];
$api_key = "AIzaSyCu9geBocTkU8OweBa1TMCZ5rlBBMSEIKs"; // Replace with your actual API Key

$url = "https://generativelanguage.googleapis.com/v1/models/gemini-pro:generateText?key=$api_key";

// Prepare request for AI
$request_body = json_encode([
    "contents" => [
        ["parts" => [["text" => "Based on the following job seeker profile, suggest the top 5 job matches:\n\n" . $preferences]]]
    ]
]);

// Call API using cURL
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ["Content-Type: application/json"]);
curl_setopt($ch, CURLOPT_POSTFIELDS, $request_body);
$response = curl_exec($ch);

// Handle API errors
if (curl_errno($ch)) {
    echo json_encode(["error" => curl_error($ch)]);
    exit;
}
curl_close($ch);

// Parse response
$response_data = json_decode($response, true);
if (!$response_data || !isset($response_data["candidates"][0]["content"]["parts"][0]["text"])) {
    echo json_encode(["error" => "Invalid API response", "raw_response" => $response]);
    exit;
}

$jobs = $response_data["candidates"][0]["content"]["parts"][0]["text"];

// Return AI suggestions
echo json_encode(["jobs" => $jobs]);
?>
