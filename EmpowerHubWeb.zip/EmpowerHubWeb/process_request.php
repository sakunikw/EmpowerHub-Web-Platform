<?php
include 'Connection_db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $mentor_id = intval($_POST['mentor_id']);
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $date = $_POST['date'];
    $time = $_POST['time'];
    $message = trim($_POST['message']);

    if (empty($mentor_id) || empty($name) || empty($email) || empty($date) || empty($time) || empty($message)) {
        die("All fields are required.");
    }

    $sql = "INSERT INTO consultation_requests (mentor_id, name, email, date, time, message) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isssss", $mentor_id, $name, $email, $date, $time, $message);

    if ($stmt->execute()) {
        echo "<script>alert('Consultation request sent successfully!'); window.location.href='mentor_panel.php';</script>";
    } else {
        echo "<script>alert('Error submitting request. Please try again.'); window.history.back();</script>";
    }
}
?>
