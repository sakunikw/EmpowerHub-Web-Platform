<?php
session_start();
include 'Connection_db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $job_id = $_POST['job_id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $cover_letter = $_POST['cover_letter'];

    // File upload handling
    $targetDir = "uploads/cv/";
    if (!file_exists($targetDir)) {
        mkdir($targetDir, 0777, true);
    }

    $fileName = basename($_FILES["cv_file"]["name"]);
    $filePath = $targetDir . time() . "_" . $fileName; // Add timestamp to avoid duplicates
    $fileType = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));

    // Validate file type
    $allowedTypes = ["pdf", "doc", "docx"];
    if (!in_array($fileType, $allowedTypes)) {
        echo "<script>alert('Invalid file type. Only PDF, DOC, and DOCX files are allowed.'); window.location.href='application_page.php';</script>";
        exit;
    }

    // Move file to server
    if (move_uploaded_file($_FILES["cv_file"]["tmp_name"], $filePath)) {
        // Insert application into the database
        $stmt = $conn->prepare("INSERT INTO job_applications (job_id, applicant_name, applicant_email, cover_letter, cv_file) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("issss", $job_id, $name, $email, $cover_letter, $filePath);

        if ($stmt->execute()) {
            $message = "Application submitted successfully. Thank you for applying!";
        } else {
            $message = "Error submitting your application. Please try again.";
        }
    } else {
        $message = "Error uploading file. Please try again.";
    }
} else {
    // If the form is not submitted via POST
    $message = "Invalid request.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Application Submission Confirmation | EmpowerHub</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="#">EmpowerHub</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="Networking.php">Networking</a></li>
                <li class="nav-item"><a class="nav-link" href="Mentor_panel.php">Mentors</a></li>
                <li class="nav-item"><a class="nav-link" href="startups_post_vacancy.php">Post Job Vacancies</a></li>
                <li class="nav-item"><a class="nav-link" href="startups_view_job_applicants.php">View Job Applications</a></li>
                <li class="nav-item"><a class="nav-link btn btn-light text-primary" href="Logout.php">Logout</a></li>
            </ul>
        </div> 
    </div>
</nav>

<!-- Main Content -->
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="alert alert-info text-center" role="alert">
                <h4 class="alert-heading">Application Status</h4>
                <p><?php echo $message; ?></p>
                <hr>
                <p class="mb-0">If you have any questions, please contact support.</p>
                <a href="startups_view_job_applicants.php" class="btn btn-primary mt-3">Back to Job Listings</a>
            </div>
        </div>
    </div>
</div>

</body>
</html>
