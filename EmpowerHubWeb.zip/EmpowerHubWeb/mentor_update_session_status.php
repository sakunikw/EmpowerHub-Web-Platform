<?php
session_start();
include 'Connection_db.php'; // Ensure this file contains a valid `$conn` database connection

// Check if mentor is logged in
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    echo "<script>alert('You need to be logged in as a mentor to perform this action.'); window.location.href='MentorSignIn.php';</script>";
    exit();
}

// Get data from form
if (!isset($_POST['request_id']) || !isset($_POST['action'])) {
    echo "<script>alert('Invalid request.'); window.location.href='MentorHome.php';</script>";
    exit();
}

$mentor_id = $_SESSION['user_id'];
$request_id = $_POST['request_id'];
$action = $_POST['action'];

// Check if the request belongs to the mentor
$sql_check = "SELECT * FROM consultation_requests WHERE id = ? AND mentor_id = ?";
$stmt_check = $conn->prepare($sql_check);
$stmt_check->bind_param("ii", $request_id, $mentor_id);
$stmt_check->execute();
$result_check = $stmt_check->get_result();

if ($result_check->num_rows == 0) {
    echo "<script>alert('Unauthorized action.'); window.location.href='MentorHome.php';</script>";
    exit();
}

// Determine new status
$action = strtolower($_POST['action']); // Convert to lowercase for consistency
$new_status = ($action == 'approve') ? 'Approved' : 'Rejected';




// Update request status
$sql_update = "UPDATE consultation_requests SET status = ? WHERE id = ?";
$stmt_update = $conn->prepare($sql_update);
$stmt_update->bind_param("si", $new_status, $request_id);

if ($stmt_update->execute()) {
    echo "<script>alert('Request " . $new_status . " successfully!'); window.location.href='MentorHome.php';</script>";
} else {
    echo "<script>alert('Failed to update request. Please try again.'); window.location.href='MentorHome.php';</script>";
}
?>
