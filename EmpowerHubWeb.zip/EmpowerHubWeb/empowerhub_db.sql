-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3308
-- Generation Time: Mar 25, 2025 at 02:29 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `empowerhub_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`id`, `username`, `password`) VALUES
(1, 'admin1', 'Admin1'),
(2, 'admin2', 'Admin2'),
(3, 'admin3', 'Admin3');

-- --------------------------------------------------------

--
-- Table structure for table `consultation_requests`
--

CREATE TABLE `consultation_requests` (
  `id` int(11) NOT NULL,
  `mentor_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `message` text NOT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `meeting_link` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `consultation_requests`
--

INSERT INTO `consultation_requests` (`id`, `mentor_id`, `name`, `email`, `date`, `time`, `message`, `status`, `meeting_link`) VALUES
(1, 3, 'janani', 'janani@gmail.com', '2025-03-19', '08:58:00', 'hsajkkskska', '', NULL),
(2, 3, 'kaveesha', 'mary@gmail.com', '2025-03-19', '19:25:00', 'asdfghjkl', '', NULL),
(4, 3, 'kaveesha', 'kavi@gmail.com', '2025-03-25', '13:40:00', 'dfghjklmnbvc', '', NULL),
(5, 3, 'janani', 'janani@gmail.com', '2025-03-12', '14:54:00', 'xcvbnm,mnbvcx', 'rejected', NULL),
(6, 3, 'janani', 'janani@gmail.com', '2025-03-04', '22:02:00', 'xcvbnm,mnbvcx', 'approved', NULL),
(7, 3, 'Ann Cliara', 'ann@gmail.com', '2025-02-23', '05:04:00', 'xcvbnm', 'approved', NULL),
(8, 3, 'kaveesha', 'kavi@gmail.com', '2025-03-25', '15:15:00', '15min meeting', 'approved', NULL),
(9, 3, 'Janani', 'janani@gmail.com', '2025-03-12', '10:13:00', 'request for a 15 min meeating', 'approved', NULL),
(10, 3, 'silva', 'silva@gmail.com', '2025-03-13', '05:33:00', 'hgfdsdfghjk', 'approved', NULL),
(11, 3, 'kaveesha', 'kavi@gmail.com', '2025-03-18', '02:27:00', 'sdfghjkl', 'approved', NULL),
(12, 3, 'kaveesha', 'kavi@gmail.com', '2025-03-22', '02:27:00', 'asdfghiuytre', 'approved', NULL),
(13, 3, 'Siara De Silva', 'siara@gmail.com', '2025-04-22', '22:26:00', 'I need a 15 min session', 'pending', NULL),
(14, 5, 'kaveesha', 'kavi@gmail.com', '2025-04-09', '23:37:00', 'Need to discuss about my new project in apparel', 'approved', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `contact_messages`
--

CREATE TABLE `contact_messages` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact_messages`
--

INSERT INTO `contact_messages` (`id`, `name`, `email`, `message`, `created_at`) VALUES
(2, 'kaveesha', 'sakunikaveeshaw@gmail.com', 'Can i know about empowerhub?', '2025-03-21 18:04:33');

-- --------------------------------------------------------

--
-- Table structure for table `investments`
--

CREATE TABLE `investments` (
  `id` int(11) NOT NULL,
  `investor_id` int(11) NOT NULL,
  `investor_name` varchar(255) NOT NULL,
  `investor_email` varchar(255) NOT NULL,
  `project_id` int(11) NOT NULL,
  `project_title` varchar(255) NOT NULL,
  `category` varchar(100) NOT NULL,
  `budget` decimal(10,2) NOT NULL,
  `innovator_name` varchar(255) NOT NULL,
  `invested_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `innovator_email` varchar(255) NOT NULL,
  `file_path` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `investments`
--

INSERT INTO `investments` (`id`, `investor_id`, `investor_name`, `investor_email`, `project_id`, `project_title`, `category`, `budget`, `innovator_name`, `invested_at`, `innovator_email`, `file_path`) VALUES
(15, 1, 'jessica perera', 'jessica@gmail.com', 2, 'Renewable Energy for Rural Areas', 'Agriculture', 100.00, 'Bimal De Silva', '2025-03-22 17:44:54', 'bimal@gmail.com', 'uploads/sss (1).pdf');

-- --------------------------------------------------------

--
-- Table structure for table `job_applications`
--

CREATE TABLE `job_applications` (
  `id` int(11) NOT NULL,
  `job_id` int(11) NOT NULL,
  `applicant_name` varchar(255) NOT NULL,
  `applicant_email` varchar(255) NOT NULL,
  `cover_letter` text NOT NULL,
  `cv_file` varchar(255) NOT NULL,
  `application_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `job_applications`
--

INSERT INTO `job_applications` (`id`, `job_id`, `applicant_name`, `applicant_email`, `cover_letter`, `cv_file`, `application_date`) VALUES
(2, 3, 'kaveesha', 'kavi@gmail.com', ' I\'m creative and skilled Fashion Designer i like to join your team', 'uploads/cv/1742585239_1742583017_sss.pdf', '2025-03-21 19:27:19'),
(3, 3, 'Dula', 'dula@gmail.com', 'loeumipsumloeumipsuloeumipsumloeumipsum', 'uploads/cv/1742756906_sss (1) (2).pdf', '2025-03-23 19:08:26');

-- --------------------------------------------------------

--
-- Table structure for table `job_postings`
--

CREATE TABLE `job_postings` (
  `id` int(11) NOT NULL,
  `startup_email` varchar(100) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `qualifications` text DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `salary` decimal(10,2) DEFAULT NULL,
  `job_type` varchar(50) DEFAULT NULL,
  `posted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `job_postings`
--

INSERT INTO `job_postings` (`id`, `startup_email`, `title`, `description`, `category`, `qualifications`, `location`, `salary`, `job_type`, `posted_at`) VALUES
(1, 'janani@gmail.com', 'dfghjk', 'fdsdfghjk.,mnbvc', 'Digital Marketing', 'kjhgfdcvbnm', 'Kandy', 12345.00, 'Full-time', '2025-03-16 18:38:39'),
(2, 'janani@gmail.com', 'supervisor for food factory', 'We are looking for an experienced Food Factory Supervisor to oversee production, ensure safety and quality standards, and lead a team in a fast-paced environment. Strong leadership and food safety knowledge required. Experience in food production is preferred.', 'Food & Beverage', '1 year or more experience in same industry', 'colombo', 900000.00, 'Full-time', '2025-03-22 00:11:13'),
(3, 'janani@gmail.com', 'Fashion Designer', 'We are looking for a creative and skilled Fashion Designer to join our team. The ideal candidate will have a passion for fashion, an eye for detail, and experience in designing clothing and accessories.', 'Retail & Sales', 'Any diploma or experience needed', 'Negombo', 120000.00, 'Part-time', '2025-03-22 00:50:03'),
(4, 'janani@gmail.com', 'fashion designer', 'lorumipsumlorumipsumlorumipsumlorumipsumlorumipsum', 'Retail & Sales', 'lorumipsumlorumipsum', 'kandy', 12000.00, 'Full-time', '2025-03-24 00:26:39');

-- --------------------------------------------------------

--
-- Table structure for table `mentees`
--

CREATE TABLE `mentees` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mentees`
--

INSERT INTO `mentees` (`id`, `full_name`, `email`, `password`, `created_at`) VALUES
(1, 'Janani Perera', 'janani@gmail.com', '$2y$10$vWxl/z1dCwND5XVWbWwhjevutQHJ1Dbpom4ri3ZNNh.x/DbslafGC', '2025-03-09 04:02:05'),
(2, 'kaveesha', 'kavi@gmail.com', '$2y$10$tpiKW8h7Q0VM4NHKQwVxzuWFcbQVXeKUtBGz1tKcwPvTOkDfjg7MO', '2025-03-09 17:12:42'),
(3, 'Ann Cliara', 'ann@gmail.com', '$2y$10$zU5j3xYe5YHdys4bab4oXuLKYSGXlQn7rDPxO9UY4xPdN9j7QAqxK', '2025-03-09 19:19:25'),
(5, 'Siara De Silva', 'siara@gmail.com', '$2y$10$1dJzsGZL1ScZSMCs.MtFEu8famzVwj7geFI7K0vwIS25ovZPbk/3S', '2025-03-12 22:13:24');

-- --------------------------------------------------------

--
-- Table structure for table `mentors`
--

CREATE TABLE `mentors` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mentors`
--

INSERT INTO `mentors` (`id`, `username`, `email`, `password`, `created_at`) VALUES
(2, 'Amal', 'amal@gmail.com', '$2y$10$80DWdrD.wXlVpNWLtpDXD.Esk4VVMlW.8FN19bVg58bk6JxjoJCIe', '2025-03-05 20:06:44'),
(3, 'kavin', 'kavin@gmail.com', '$2y$10$p6jc6IpSHGcz/lPVMOspVu0rEFFTymWjFm9oTnJ4yTL9KSCJnzuPi', '2025-03-05 21:50:58'),
(4, 'Dilan', 'disal@gmail.com', '$2y$10$Hh10gxYZgqwjXhKkE5ueAupbnXWmU9ljgZtpVrEI5ambCHtsk0Kne', '2025-03-05 22:46:41'),
(5, 'Rose', 'rose@gmail.com', '$2y$10$aYXbosSaqqQqvDfql3b1DuoIF5e951Z55DSY/ZOmHl8/KroO5S3ry', '2025-03-09 19:45:59'),
(6, 'Diana Megan', 'diana@gmail.com', '$2y$10$UqJWMBWf5FBGBEidZDEBLeNHa23B.Q9QM4O1.mug0qmMzWOlSXfQ.', '2025-03-10 18:00:14'),
(7, 'Sakuni', 'sakuni@gmail.com', '$2y$10$hZSXb8RExFl/b0R3uPFsZe2GUlOQ0VeHnKGZVjJxQ9RlIXaAPMKmS', '2025-03-12 19:32:32'),
(8, 'Andrea  Dias', 'andrea@gmail.com', '$2y$10$OY2Tr4jCJ64kIJ26cfnrSewQfcoRwCIAUurlTQ3UftO/IZ4vb9OlS', '2025-03-23 15:57:10');

-- --------------------------------------------------------

--
-- Table structure for table `mentor_verification`
--

CREATE TABLE `mentor_verification` (
  `verification_id` int(11) NOT NULL,
  `mentor_id` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `country` varchar(100) NOT NULL,
  `linkedin` varchar(255) NOT NULL,
  `experience` int(11) NOT NULL,
  `industry` varchar(255) NOT NULL,
  `bio` text NOT NULL,
  `motivation` text NOT NULL,
  `availability` varchar(255) NOT NULL,
  `profile_picture` varchar(255) NOT NULL,
  `certificate_path` varchar(255) NOT NULL,
  `gov_id_path` varchar(255) NOT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mentor_verification`
--

INSERT INTO `mentor_verification` (`verification_id`, `mentor_id`, `full_name`, `email`, `phone`, `country`, `linkedin`, `experience`, `industry`, `bio`, `motivation`, `availability`, `profile_picture`, `certificate_path`, `gov_id_path`, `status`, `created_at`) VALUES
(2, 3, 'kavin perera', 'kavin@gmail.com', '0765986563', 'Sri Lanka', 'https://www.linkedin.com/in/johndoe12345', 12, 'export import', 'sdfghjkmnbvcxzxcvbn', 'sdbnmbvcxcvbnm', 'weekends', 'uploads/saku.jpg', 'uploads/Screenshot (665).png', 'uploads/Screenshot (668).png', 'approved', '2025-03-05 22:03:12'),
(5, 6, 'Diana Megan', 'diana@gmail.com', '07764321134', 'Sri Lanka', 'https://www.linkedin.com/in/diana123', 15, 'Food Manufacturing', 'Experienced food manufacturing mentor specializing in product development, food safety, process optimization, and regulatory compliance, with over [X] years guiding businesses to success in the industry.', 'guide future', 'weekends', 'uploads/business-woman-2756210_1280.jpg', 'uploads/Screenshot (663).png', 'uploads/Screenshot (669).png', 'approved', '2025-03-10 18:04:38'),
(6, 5, 'Rose', 'rose@gmail.com', '07764321135', 'Sri Lanka', 'https://www.linkedin.com/in/rose123', 9, 'Apparel Industry', 'LorumIpsumLorumIpsumLorumIpsumLorumIpsumLorumIpsumLorumIpsumLorumIpsum', 'lorumipsumlorumipsumlorumipsumlorumipsum', 'Weekdays', 'uploads/rose.jpg', 'uploads/Screenshot (665).png', 'uploads/Screenshot (669).png', 'approved', '2025-03-12 19:54:31'),
(7, 8, 'Andrea  Dias', 'andrea@gmail.com', '0774568923', 'Sri Lanka', 'https://www.linkedin.com/in/andrea12345', 14, 'textlite', 'lorumipsumlorumipsunlorumipsumlorumipsumlorumipsum', 'lorumipsunlorumipsunlorumipsunlorumipsun', 'weekends', 'uploads/Screenshot (705).png', 'uploads/Screenshot (671).png', 'uploads/Screenshot (668).png', 'pending', '2025-03-23 16:00:30');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` int(11) NOT NULL,
  `innovator_id` int(11) NOT NULL,
  `innovator_name` varchar(255) NOT NULL,
  `innovator_email` varchar(255) NOT NULL,
  `contact_number` varchar(20) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `category` enum('Tech','Agriculture','Healthcare','Education') NOT NULL,
  `budget` decimal(10,2) NOT NULL,
  `timeline` int(11) NOT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `status` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `innovator_id`, `innovator_name`, `innovator_email`, `contact_number`, `title`, `description`, `category`, `budget`, `timeline`, `file_path`, `status`, `created_at`) VALUES
(1, 2, 'Bimal De Silva', 'bimal@gmail.com', '0776543455', 'sdfghjkl', 'dfghjk,mnbvcx', 'Tech', 21.00, 12, 'uploads/sss.pdf', 'Approved', '2025-03-20 14:05:33'),
(2, 2, 'Bimal De Silva', 'bimal@gmail.com', '0776543455', 'Renewable Energy for Rural Areas', 'Environment', 'Agriculture', 100.00, 13, 'uploads/sss (1).pdf', 'Approved', '2025-03-22 17:27:35'),
(3, 2, 'Bimal De Silva', 'bimal@gmail.com', '0776543455', 'lorumipsumlorumipsum', 'lorumipsumlorumipsum', 'Tech', 12000.00, 7, 'uploads/sss (1).pdf', 'Pending', '2025-03-23 19:23:40');

-- --------------------------------------------------------

--
-- Table structure for table `selected_applicants`
--

CREATE TABLE `selected_applicants` (
  `id` int(11) NOT NULL,
  `job_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `cover_letter` text DEFAULT NULL,
  `cv_file` varchar(255) DEFAULT NULL,
  `applied_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `selected_applicants`
--

INSERT INTO `selected_applicants` (`id`, `job_id`, `name`, `email`, `cover_letter`, `cv_file`, `applied_at`) VALUES
(1, 1, 'kaveesha', 'ksakuniweerasinghe@gmail.com', 'lorumipsumlorumipsumlorumipsumlorumipsum', 'uploads/CV_67d70b221f45d3.29723109.pdf', '2025-03-16 23:02:18'),
(2, 2, 'Ann Cliara', 'ann@gmail.com', 'Dear Hiring Manager,\r\nI am excited to apply for the Food Factory Supervisor position. \r\n', 'uploads/cv/1742583017_sss.pdf', '2025-03-22 00:20:17');

-- --------------------------------------------------------

--
-- Table structure for table `users_invest`
--

CREATE TABLE `users_invest` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('investor','innovator') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users_invest`
--

INSERT INTO `users_invest` (`id`, `fullname`, `email`, `password`, `role`, `created_at`) VALUES
(1, 'jessica perera', 'jessica@gmail.com', '$2y$10$RhNa94xHcbCXWpSq1TrNt.Vi2D14/gEeXuO13DYJ4YYaTTPdfukNe', 'investor', '2025-03-19 20:53:27'),
(2, 'Bimal De Silva', 'bimal@gmail.com', '$2y$10$7StfsEYw7fUxpAYZ3tPJCeur5RgRIBarY4YYfZF1X1QEOsqcngOm2', 'innovator', '2025-03-19 21:09:10'),
(3, 'Dian', 'dian@gmail.com', '$2y$10$h7ZLgOGbzJdi86.ag488sehrozbJIkP5.I8QEWy6sXHmgMnNmRLfm', 'innovator', '2025-03-22 18:22:21'),
(4, 'Tehara perera', 'Tehara@gmail.com', '$2y$10$GumwZ.YkmhSe3xDo73d6Je8YqYSi7UR/4WazUt0Wt2H.jfCDLUVg2', 'investor', '2025-03-22 18:27:44');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `consultation_requests`
--
ALTER TABLE `consultation_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mentor_id` (`mentor_id`);

--
-- Indexes for table `contact_messages`
--
ALTER TABLE `contact_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `investments`
--
ALTER TABLE `investments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `investor_id` (`investor_id`),
  ADD KEY `project_id` (`project_id`);

--
-- Indexes for table `job_applications`
--
ALTER TABLE `job_applications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `job_postings`
--
ALTER TABLE `job_postings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mentees`
--
ALTER TABLE `mentees`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `mentors`
--
ALTER TABLE `mentors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `mentor_verification`
--
ALTER TABLE `mentor_verification`
  ADD PRIMARY KEY (`verification_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `mentor_id` (`mentor_id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `innovator_id` (`innovator_id`);

--
-- Indexes for table `selected_applicants`
--
ALTER TABLE `selected_applicants`
  ADD PRIMARY KEY (`id`),
  ADD KEY `job_id` (`job_id`);

--
-- Indexes for table `users_invest`
--
ALTER TABLE `users_invest`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_users`
--
ALTER TABLE `admin_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `consultation_requests`
--
ALTER TABLE `consultation_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `contact_messages`
--
ALTER TABLE `contact_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `investments`
--
ALTER TABLE `investments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `job_applications`
--
ALTER TABLE `job_applications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `job_postings`
--
ALTER TABLE `job_postings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `mentees`
--
ALTER TABLE `mentees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `mentors`
--
ALTER TABLE `mentors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `mentor_verification`
--
ALTER TABLE `mentor_verification`
  MODIFY `verification_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `selected_applicants`
--
ALTER TABLE `selected_applicants`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users_invest`
--
ALTER TABLE `users_invest`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `consultation_requests`
--
ALTER TABLE `consultation_requests`
  ADD CONSTRAINT `consultation_requests_ibfk_1` FOREIGN KEY (`mentor_id`) REFERENCES `mentor_verification` (`mentor_id`) ON DELETE CASCADE;

--
-- Constraints for table `investments`
--
ALTER TABLE `investments`
  ADD CONSTRAINT `investments_ibfk_1` FOREIGN KEY (`investor_id`) REFERENCES `users_invest` (`id`),
  ADD CONSTRAINT `investments_ibfk_2` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`);

--
-- Constraints for table `mentor_verification`
--
ALTER TABLE `mentor_verification`
  ADD CONSTRAINT `mentor_verification_ibfk_1` FOREIGN KEY (`mentor_id`) REFERENCES `mentors` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `projects`
--
ALTER TABLE `projects`
  ADD CONSTRAINT `projects_ibfk_1` FOREIGN KEY (`innovator_id`) REFERENCES `users_invest` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `selected_applicants`
--
ALTER TABLE `selected_applicants`
  ADD CONSTRAINT `selected_applicants_ibfk_1` FOREIGN KEY (`job_id`) REFERENCES `job_postings` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
