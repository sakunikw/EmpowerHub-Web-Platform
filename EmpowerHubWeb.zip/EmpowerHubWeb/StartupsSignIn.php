<?php
session_start(); // Start the session

// Process the login form
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include 'Connection_db.php'; // Include your DB connection file
    $email = $_POST['email']; // Get email from form
    $password = $_POST['password']; // Get password from form

    // Query to check if the email exists
    $sql = "SELECT * FROM mentees WHERE email = ? LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($password, $user['password'])) { // If password is correct
        $_SESSION['email'] = $email; // Set the session email
        header("Location: startups_dashboard.php"); // Redirect to dashboard
        exit();
    } else {
        echo "<script>alert('Invalid login credentials.');</script>";
    }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Investor Login</title>
    <link rel="stylesheet" href="styles.css">
    
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: linear-gradient(to right, #6a5acd, #d8bfd8);
        }
        .container {
            display: flex;
            width: 80%;
            max-width: 1000px;
            background: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            overflow: hidden;
        }
        .left-section {
            flex: 1;
            background: linear-gradient(to bottom, #6a5acd, #9370db);
            background-image: url('images/img1.jpg');
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            padding: 20px;
        }
        .right-section {
            flex: 1;
            padding: 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        .logo {
            display: block;
            margin: 0 auto 20px;
            max-width: 450px;
        }
        h2 {
            text-align: center;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-top: 10px;
            font-weight: bold;
        }
        input {
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .checkbox {
            display: flex;
            align-items: center;
            margin-top: 10px;
        }
        button {
            margin-top: 20px;
            padding: 10px;
            background: #2c3e50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background: #1a252f;
        }
        p {
            text-align: center;
            margin-top: 10px;
        }
        a {
            color: #6a5acd;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <div class="container">
        <div class="left-section">
            <h1> Welcome to EmpowerHub</h1>
        </div>
        <div class="right-section">
            <img src="images/logo.png" alt="EmpowerHubLogo" class="logo">
            <h2>Sign In to Your EmpowerHub Account</h2>
            <form action="" method="POST">
                <label for="email">Email</label>
                <input type="email" name="email" id="email" placeholder="Your Email" required>
                
                <label for="password">Password</label>
                <input type="password" name="password" id="password" placeholder="Your Password" required>
                
                
                
                <button type="submit">SIGN IN</button>
                <p>Don't have an account? <a href="StartupsSignUp.php">Register</a></p>
                <p><a href="#">Forgot Password?</a></p>
            </form>
        </div>
    </div>
</body>
</html>
