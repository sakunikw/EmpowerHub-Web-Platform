<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EmpowerHub - Welcome</title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <!-- Font Awesome for Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
            color: #333;
        }

        .navbar {
            background:rgb(25, 28, 30);
            padding: 15px;
            text-align: center;
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1000;
        }

        .navbar a {
            color: white;
            text-decoration: none;
            font-size: 18px;
            margin: 0 20px;
            font-weight: bold;
            transition: 0.3s;
        }

        .navbar a:hover {
            color: #ffcc00;
        }

        .hero {
            background: url('images/img2.jpg') center/cover no-repeat;
            height: 100vh;
            color: white;
            text-align: center;
            padding: 80px 20px;
            position: relative;
            background-attachment: fixed;
        }

        .hero h1 {
            font-size: 60px;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }

        .hero p {
            font-size: 24px;
            text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.5);
        }

        .container {
            background: white;
            padding: 40px;
            margin: 20px auto;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 60%;
        }

        .role-selection {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 30px;
        }

        .button {
            display: block;
            padding: 15px;
            text-decoration: none;
            color: white;
            border-radius: 5px;
            font-size: 18px;
            font-weight: bold;
            transition: 0.3s ease-in-out;
            width: 200px;
            text-align: center;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .investor {
            background-color: #2e973e;
        }

        .investor:hover {
            background-color: #237c30;
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
        }

        .inventor {
            background-color: #0073e6;
        }

        .inventor:hover {
            background-color: #005bbd;
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
        }

        .features {
            text-align: center;
            padding: 40px;
        }

        .features h2 {
            margin-bottom: 20px;
            font-size: 36px;
            color: #333;
        }

        .feature-box {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
            gap: 20px;
        }

        .feature {
            background: #f4f4f4;
            padding: 30px;
            margin: 10px;
            border-radius: 10px;
            width: 30%;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: 0.3s;
        }

        .feature:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
        }

        .feature h3 {
            font-size: 24px;
            margin-bottom: 15px;
            color: #0073e6;
        }

        .feature p {
            font-size: 16px;
            color: #555;
        }

        .feature i {
            font-size: 40px;
            margin-bottom: 15px;
            color: #0073e6;
        }

        .footer {
            background: #333;
            color: white;
            text-align: center;
            padding: 15px;
            margin-top: 40px;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .feature-box {
                flex-direction: column;
                align-items: center;
            }

            .container {
                width: 80%;
            }

            .role-selection {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="navbar">
        <a href="Index.php">Home</a>
        <a href="#features">Features</a>
        <a href="#signup">Sign Up</a>
    </div>

    <div class="hero">
        <h1>Welcome to EmpowerHub</h1>
        <p>Connecting Investors and Innovators for a Better Future</p>
    </div>

    <div class="container" id="signup">
        <h2>Get Started</h2>
        <p>Choose your role to continue</p>
        <div class="role-selection">
            <a href="invest_signup.php?role=investor" class="button investor">I’m an Investor</a>
            <a href="invest_signup.php?role=inventor" class="button inventor">I’m an Innovator</a>
        </div>
    </div>

    <div class="features" id="features">
        <h2>How EmpowerHub Works</h2>
        <div class="feature-box">
            <div class="feature">
                <i class="fas fa-rocket"></i>
                <h3>For Investors</h3>
                <p>Discover innovative projects, support startups, and make informed investments.</p>
            </div>
            <div class="feature">
                <i class="fas fa-lightbulb"></i>
                <h3>For Innovators</h3>
                <p>Present your ideas, connect with potential investors, and bring your vision to life.</p>
            </div>
            <div class="feature">
                <i class="fas fa-shield-alt"></i>
                <h3>Secure & Verified</h3>
                <p>All users are verified, ensuring a safe and trustworthy investment ecosystem.</p>
            </div>
        </div>
    </div>

    <div class="footer">
        <p>&copy; 2025 EmpowerHub. All Rights Reserved.</p>
    </div>
</body>
</html>
