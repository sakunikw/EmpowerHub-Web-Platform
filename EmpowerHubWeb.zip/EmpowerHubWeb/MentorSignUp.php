<?php
include 'Connection_db.php'; // Includes the database connection

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["username"]);
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]); // Storing password as plain text

    // Insert into database
    $sql = "INSERT INTO mentors (username, email, password) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $username, $email, $password);  

    if ($stmt->execute()) {
        echo "<script>alert('Registration successful!'); window.location.href='MentorSignIn.php';</script>";
    } else {
        echo "<script>alert('Error: " . $conn->error . "');</script>";
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - EmpowerHub</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: rgb(81, 79, 108);
        }
        .container {
            display: flex;
            width: 80%;
            max-width: 1200px;
            background: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }
        .left-panel {
            flex: 1;
            background: url('images/img2.jpg') no-repeat center center/cover;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            padding: 20px;
        }
        .right-panel {
            flex: 1;
            padding: 40px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .logo img {
            width: 450px;
        }
        h2 {
            margin-bottom: 20px;
        }
        form {
            width: 100%;
            display: flex;
            flex-direction: column;
        }
        input {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .register-btn {
            padding: 10px;
            background: #000;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .links {
            margin-top: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .links a {
            color: #000;
            text-decoration: none;
            margin: 8px 0;
            font-weight: bold;
            font-size: 14px;
            transition: color 0.3s;
            display: flex;
            align-items: center;
        }
        .links a:hover {
            color: #6a5acd;
            text-decoration: underline;
        }
        .links a i {
            margin-right: 8px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="left-panel">
            <h1>Welcome to EmpowerHub - Investor Pool</h1>
        </div>
        <div class="right-panel">
            <div class="logo">
                <img src="images/logo.png" alt="EmpowerHub Logo">
            </div>
            <h2>Sign Up</h2>

            <!-- Sign-up Form -->
            <form action="MentorSignUp.php" method="POST">
                <input type="text" name="username" placeholder="Your Username" required>
                <input type="email" name="email" placeholder="Your Email" required>
                <input type="password" name="password" placeholder="Your Password" required>
                
                <button type="submit" class="register-btn">REGISTER</button>
            </form>

            <!-- Links for login or home page -->
            <div class="links">
                <a href="MentorSignIn.php"><i class="fas fa-user-check"></i> Already registered? Sign in</a>
                <a href="Index.php"><i class="fas fa-home"></i> Back to Home</a>
            </div>
        </div>
    </div>
</body>
</html>
