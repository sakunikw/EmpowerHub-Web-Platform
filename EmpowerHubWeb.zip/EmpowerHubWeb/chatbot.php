
<?php
header('Content-Type: application/json');

$apiKey = 'AIzaSyBXNFhrm6n0PLQ3Q7BoC0TVc-5a90WN5EA'; 
$message = $_POST['message'] ?? '';

if (!$message) {
    echo json_encode(['error' => 'No message provided']);
    exit;
}

$url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$apiKey";

$data = [
    "contents" => [
        [
            "parts" => [
                ["text" => $message]
            ]
        ]
    ]
];

$options = [
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => ["Content-Type: application/json"],
    CURLOPT_POSTFIELDS => json_encode($data),
];

$ch = curl_init();
curl_setopt_array($ch, $options);
$result = curl_exec($ch);

if (curl_errno($ch)) {
    echo json_encode(['error' => 'Request failed: ' . curl_error($ch)]);
} else {
    $decodedResult = json_decode($result, true);

    // Save response for debugging
    file_put_contents("debug_log.txt", json_encode($decodedResult, JSON_PRETTY_PRINT));

    // Check API response structure
    if (isset($decodedResult['candidates'][0]['content']['parts'][0]['text'])) {
        echo json_encode(['response' => $decodedResult['candidates'][0]['content']['parts'][0]['text']]);
    } else {
        echo json_encode(['error' => 'Invalid API response format', 'debug' => $decodedResult]);
    }
}

curl_close($ch);
?>
