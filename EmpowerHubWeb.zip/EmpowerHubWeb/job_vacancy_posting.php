<?php
session_start();
include 'Connection_db.php';

if (!isset($_SESSION['email'])) {
    echo "<script>alert('Please login to post a job.'); window.location.href='StartupsSignIn.php';</script>";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $startup_email = $_SESSION['email'];
    $jobTitle = trim($_POST['jobTitle']);
    $jobDescription = trim($_POST['jobDescription']);
    $jobCategory = trim($_POST['jobCategory']);
    $jobQualifications = trim($_POST['jobQualifications']);
    $jobLocation = trim($_POST['jobLocation']);
    $jobSalary = floatval($_POST['jobSalary']);
    $jobType = trim($_POST['jobType']);

    // Prepared Statement
    $stmt = $conn->prepare("INSERT INTO job_postings (startup_email, title, description, category, qualifications, location, salary, job_type, posted_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
    $stmt->bind_param("ssssssds", $startup_email, $jobTitle, $jobDescription, $jobCategory, $jobQualifications, $jobLocation, $jobSalary, $jobType);

    if ($stmt->execute()) {
        echo "<script>alert('Job Posted Successfully!'); window.location.href='startups_dashboard.php';</script>";
    } else {
        echo "<script>alert('Error posting job: " . $stmt->error . "'); window.history.back();</script>";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Post Job Vacancy | EmpowerHub</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    .section-title {
      margin-top: 50px;
      font-weight: bold;
      font-size: 2rem;
      text-align: center;
    }
    .job-posting-box {
      background-color: #f0f8ff;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    .form-group {
      margin-bottom: 1.5rem;
    }
  </style>
</head>
<body>

  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">EmpowerHub</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a class="nav-link active" href="startups_dashboard.php">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="#">Services</a></li>
          <li class="nav-item"><a class="nav-link" href="#">Contact</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Job Posting Form -->
  <div class="container my-5">
    <h2 class="section-title">Post a Job Vacancy</h2>
    <div class="job-posting-box">
      <h4>📢 Post Your Job Vacancy</h4>
      <p>Need extra hands for your business? Fill out the form below to post your job vacancy.</p>

      <form id="jobForm" action="job_vacancy_posting.php" method="post">
        <div class="form-group">
          <label for="jobTitle">Job Title</label>
          <input type="text" class="form-control" id="jobTitle" name="jobTitle" required>
        </div>

        <div class="form-group">
          <label for="jobDescription">Job Description</label>
          <textarea class="form-control" id="jobDescription" name="jobDescription" rows="4" required></textarea>
        </div>

        <div class="form-group">
          <label for="jobCategory">Job Category</label>
          <select class="form-select" id="jobCategory" name="jobCategory" required>
            <option value="" disabled selected>Select a category</option>
            <option value="Food & Beverage">Food & Beverage</option>
            <option value="Retail & Sales">Retail & Sales</option>
            <option value="Delivery & Logistics">Delivery & Logistics</option>
            <option value="Digital Marketing">Digital Marketing</option>
            <option value="Design & Branding">Design & Branding</option>
            <option value="Office Assistants & Admin">Office Assistants & Admin</option>
          </select>
        </div>

        <div class="form-group">
          <label for="jobQualifications">Qualifications</label>
          <textarea class="form-control" id="jobQualifications" name="jobQualifications" rows="2" required></textarea>
        </div>

        <div class="form-group">
          <label for="jobLocation">Location</label>
          <input type="text" class="form-control" id="jobLocation" name="jobLocation" required>
        </div>

        <div class="form-group">
          <label for="jobSalary">Salary (LKR)</label>
          <input type="number" step="0.01" class="form-control" id="jobSalary" name="jobSalary" required>
        </div>

        <div class="form-group">
          <label for="jobType">Job Type</label>
          <select class="form-select" id="jobType" name="jobType" required>
            <option value="" disabled selected>Select job type</option>
            <option value="Full-time">Full-time</option>
            <option value="Part-time">Part-time</option>
            <option value="Freelance">Freelance</option>
          </select>
        </div>

        <button type="submit" class="btn btn-primary mt-3">Post Job</button>
      </form>
    </div>
  </div>

  <!-- Footer -->
  <footer class="bg-dark text-white text-center py-4">
    <p>&copy; 2025 EmpowerHub. All Rights Reserved.</p>
  </footer>

  <!-- Scripts -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    document.getElementById("jobForm").addEventListener("submit", function(e) {
      const requiredFields = ['jobTitle', 'jobDescription', 'jobCategory', 'jobQualifications', 'jobLocation', 'jobSalary', 'jobType'];
      for (let field of requiredFields) {
        if (!document.getElementById(field).value.trim()) {
          e.preventDefault();
          alert("Please fill in all fields.");
          return;
        }
      }
    });
  </script>
</body>
</html>
