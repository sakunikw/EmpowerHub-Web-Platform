
<?php
session_start();
include 'Connection_db.php';

if (isset($_POST['add_mentee'])) {
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Secure password

    $sql = "INSERT INTO mentees (full_name, email, password) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $full_name, $email, $password);
    
    if ($stmt->execute()) {
        $_SESSION['message'] = "Mentee added successfully!";
    } else {
        $_SESSION['message'] = "Error adding mentee.";
    }
    header("Location: Admin_manage_users.php");
    exit();
}
?>