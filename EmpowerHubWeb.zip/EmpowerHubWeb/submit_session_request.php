<?php
include 'Connection_db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $mentor_email = trim($_POST["mentor_email"]); 
    $user_name = trim($_POST["user_name"]);
    $user_email = trim($_POST["user_email"]);
    $session_date = $_POST["session_date"];
    $session_time = $_POST["session_time"];
    $message = trim($_POST["message"]);

    $sql = "INSERT INTO session_requests (mentor_email, user_name, user_email, session_date, session_time, message) 
            VALUES (?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssss", $mentor_email, $user_name, $user_email, $session_date, $session_time, $message);

    if ($stmt->execute()) {
        echo "<script>alert('Session request submitted successfully!'); window.location.href='verified_mentors.php';</script>";
    } else {
        echo "<script>alert('Error submitting request!');</script>";
    }

    $stmt->close();
}
$conn->close();
?>
