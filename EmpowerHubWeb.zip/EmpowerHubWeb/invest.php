<?php
session_start();
include "connection_db.php"; // Include database connection

// Ensure the investor is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'investor') {
    header("Location: invest_signin.php");
    exit();
}

// Get investor details from session
$investor_id = $_SESSION['user_id'];
$investor_name = $_SESSION['fullname'];
$investor_email = $_SESSION['email'];

// Check if project ID is provided
if (!isset($_GET['project_id']) || empty($_GET['project_id'])) {
    $_SESSION['error'] = "Invalid project selection.";
    header("Location: investor.php");
    exit();
}

$project_id = intval($_GET['project_id']); // Ensure project_id is an integer

// Fetch project details securely
$sql = "SELECT title, category, budget, innovator_name, innovator_email, file_path FROM projects WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $project_id);
$stmt->execute();
$result = $stmt->get_result();

// Check if project exists
if ($result->num_rows === 0) {
    $_SESSION['error'] = "Project not found.";
    header("Location: investor.php");
    exit();
}

$project = $result->fetch_assoc();

// Check if the investor has already invested in this project
$check_sql = "SELECT id FROM investments WHERE investor_id = ? AND project_id = ?";
$check_stmt = $conn->prepare($check_sql);
$check_stmt->bind_param("ii", $investor_id, $project_id);
$check_stmt->execute();
$check_result = $check_stmt->get_result();

if ($check_result->num_rows > 0) {
    $_SESSION['error'] = "You have already invested in this project.";
    header("Location: investor.php");
    exit();
}

// Begin transaction to ensure data consistency
$conn->begin_transaction();

try {
    // Insert investment details
    $insert_sql = "INSERT INTO investments 
    (investor_id, investor_name, investor_email, project_id, project_title, category, budget, innovator_name, invested_at, innovator_email, file_path) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?, ?)";

    $insert_stmt = $conn->prepare($insert_sql);

    // Binding parameters correctly
    $insert_stmt->bind_param(
        "ississdsss", // parameter types for each value (string, string, string, string, string, string, double, string, string, string)
        $investor_id, 
        $investor_name, 
        $investor_email, 
        $project_id, 
        $project['title'], 
        $project['category'], 
        $project['budget'], 
        $project['innovator_name'], 
        $project['innovator_email'], 
        $project['file_path']
    );

    // Debugging: check values being inserted
    error_log("Inserting investment: " . json_encode([
        'investor_id' => $investor_id,
        'investor_name' => $investor_name,
        'investor_email' => $investor_email,
        'project_id' => $project_id,
        'project_title' => $project['title'],
        'category' => $project['category'],
        'budget' => $project['budget'],
        'innovator_name' => $project['innovator_name'],
        'innovator_email' => $project['innovator_email'],
        'file_path' => $project['file_path']
    ]));

    // Execute the statement
    if ($insert_stmt->execute()) {
        // Commit transaction
        $conn->commit();
        $_SESSION['success'] = "Investment successful!";
        header("Location: imy_investments.php"); 
        exit();
    } else {
        $_SESSION['error'] = "Error in investing: " . $insert_stmt->error;
        header("Location: investor.php");
        exit();
    }

} catch (Exception $e) {
    $conn->rollback(); // Rollback on error
    $_SESSION['error'] = "Error in investing: " . $e->getMessage();
    header("Location: investor.php");
    exit();
}

// Close statements and connection
$stmt->close();
$insert_stmt->close();
$check_stmt->close();
$conn->close();
?>
