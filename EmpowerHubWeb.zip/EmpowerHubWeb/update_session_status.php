<?php
session_start();
include 'Connection_db.php';

if (!isset($_SESSION["email"])) {
    header("Location: MentorSignIn.php");
    exit();
}

if (isset($_GET['email']) && isset($_GET['status'])) {
    $mentor_email = $_SESSION["email"]; // Get mentor email from session
    $status = $_GET['status'];

    if ($status != 'approved' && $status != 'rejected') {
        die("Invalid status.");
    }

    $sql = "UPDATE session_requests SET status = ? WHERE mentor_email = ? AND status = 'pending'";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $status, $mentor_email);

    if ($stmt->execute()) {
        echo "<script>alert('Request updated successfully!'); window.location.href='mentor_dashboard.php';</script>";
    } else {
        echo "<script>alert('Error updating request!');</script>";
    }

    $stmt->close();
}
$conn->close();
?>
