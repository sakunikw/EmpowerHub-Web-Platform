<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION["user_id"])) {
    header("Location: MentorSignIn.php"); // Redirect if not logged in
    exit;
}

include 'Connection_db.php';
$mentor_id = $_SESSION['user_id'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mentor Dashboard - EmpowerHub</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Reset and Box Sizing */
        * {
            box-sizing: border-box;
        }
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        /* Container styling for full-page responsiveness */
        .container {
            display: flex;
            flex-wrap: wrap;
            min-height: 100vh;
            width: 100%;
        }
        /* Left Panel Styling */
        .left-panel {
            flex: 1 1 300px;
            background: linear-gradient(to bottom, #6a5acd, #9370db);
            color: white;
            padding: 30px;
            text-align: center;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        .left-panel h1 {
            font-size: 2em;
            margin-bottom: 15px;
        }
        .left-panel p {
            font-size: 1.2em;
        }
        /* Right Panel Styling */
        .right-panel {
            flex: 2 1 500px;
            padding: 20px;
        }
        /* Profile Section */
        .profile {
            text-align: center;
            margin-bottom: 20px;
        }
        .profile h2 {
            font-size: 1.6em;
            color: #333;
        }
        /* Menu */
        .menu {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            background-color: #6a5acd;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .menu a {
            color: white;
            font-size: 1.1em;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            margin: 5px;
        }
        .menu a:hover {
            background-color: #9370db;
        }
        /* Dashboard Sections */
        .dashboard-section {
            background: #fff;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s;
        }
        .dashboard-section:hover {
            transform: scale(1.02);
        }
        /* Make the entire dashboard section clickable */
        .dashboard-section a {
            display: block;
            color: inherit;
            text-decoration: none;
        }
        .dashboard-section h3 {
            margin-bottom: 10px;
            color: #6a5acd;
        }
        /* Footer */
        footer {
            text-align: center;
            margin-top: 20px;
            font-size: 1.1em;
        }
        /* Responsive adjustments */
        @media (max-width: 768px) {
            .container {
                flex-direction: column;
            }
            .left-panel, .right-panel {
                flex: 1 1 100%;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Left Panel -->
        <div class="left-panel">
            <h1>Welcome to EmpowerHub, Mentor!</h1>
            <p>Help shape the future of entrepreneurs. Let's get started!</p>
        </div>
        <!-- Right Panel -->
        <div class="right-panel">
            <div class="profile">
                <h2>Welcome,<?php echo $_SESSION['username']; ?></h2>
            </div>
            <!-- Menu -->
            <div class="menu">
                <a href="mentor_profile.php">My Profile</a>
                <a href="Mentor_form.php">Verify As Mentor</a>
                <a href="mentor_logout.php">Logout</a>
            </div>
            <!-- Mentorship Requests -->
            <div class="dashboard-section">
                <a href="mentor_dashboard.php">
                    <h3>Mentorship Requests</h3>
                    <p>View and respond to pending mentorship requests.</p>
                </a>
            </div>
            <!-- Session Scheduling -->
            <div class="dashboard-section">
                <a href="session_scheduling.php">
                    <h3>Session Scheduling</h3>
                    <p>Manage and schedule your mentorship sessions.</p>
                </a>
            </div>
            <!-- Messaging System -->
            <div class="dashboard-section">
                <a href="messages.php">
                    <h3>Messages</h3>
                    <p>Check your messages and communicate with mentees.</p>
                </a>
            </div>
            <!-- Resource Library -->
            <div class="dashboard-section">
                <a href="resource_library.php">
                    <h3>Resource Library</h3>
                    <p>Access and share business-related resources.</p>
                </a>
            </div>
            <!-- Notifications -->
            <div class="dashboard-section">
                <a href="notifications.php">
                    <h3>Notifications</h3>
                    <p>Stay updated with new requests, messages, and session updates.</p>
                </a>
            </div>
            <!-- Footer -->
            <footer>
                &copy; 2025 EmpowerHub. All rights reserved.
            </footer>
        </div>
    </div>
</body>
</html>
