<?php
session_start(); // Start session
include 'Connection_db.php'; // Include database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["username"]);
    $password = trim($_POST["password"]);

    // Check if user exists (by username OR email)
    $sql = "SELECT id, username, email, password FROM mentors WHERE username = ? OR email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $username, $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();

        // Check if passwords match (plain text comparison)
        if ($password == $user['password']) {
            $_SESSION["user_id"] = $user['id'];
            $_SESSION["username"] = $user['username'];

            echo "<script>alert('Login successful!'); window.location.href='MentorHome.php';</script>";
        } else {
            echo "<script>alert('Invalid password!');</script>";
        }
    } else {
        echo "<script>alert('User not found!');</script>";
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Investor Login</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: linear-gradient(to right, #6a5acd, #d8bfd8);
        }
        .container {
            display: flex;
            width: 80%;
            max-width: 1000px;
            background: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            overflow: hidden;
        }
        .left-section {
            flex: 1;
            background: linear-gradient(to bottom, #6a5acd, #9370db);
            background-image: url('images/img1.jpg');
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            padding: 20px;
        }
        .right-section {
            flex: 1;
            padding: 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        .logo {
            display: block;
            margin: 0 auto 20px;
            max-width: 450px;
        }
        h2 {
            text-align: center;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-top: 10px;
            font-weight: bold;
        }
        input {
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .checkbox {
            display: flex;
            align-items: center;
            margin-top: 10px;
        }
        button {
            margin-top: 20px;
            padding: 10px;
            background: #2c3e50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background: #1a252f;
        }
        p {
            text-align: center;
            margin-top: 10px;
        }
        a {
            color: #6a5acd;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="left-section">
            <h1>Welcome to EmpowerHub</h1>
        </div>
        <div class="right-section">
            <img src="images/logo.png" alt="EmpowerHubLogo" class="logo">
            <h2>Sign in</h2>
            <form action="MentorSignIn.php" method="POST">
                <label for="username">Username or Email</label>
                <input type="text" name="username" id="username" placeholder="Your Username or Email" required>
                
                <label for="password">Password</label>
                <input type="password" name="password" id="password" placeholder="Your Password" required>
                
                <div class="checkbox">
                    <input type="checkbox" id="remember" name="remember">
                    <label for="remember">Keep me signed in</label>
                </div>
                
                <button type="submit">SIGN IN</button>
                <p>Don't have an account? <a href="MentorSignUp.php">Register</a></p>
                <p><a href="#">Forgot Password?</a></p>
            </form>
        </div>
    </div>
</body>
</html>
