<?php
include 'Connection_db.php';

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$category = isset($_GET['category']) ? trim($_GET['category']) : '';
$location = isset($_GET['location']) ? trim($_GET['location']) : '';

$query = "SELECT * FROM job_postings WHERE 1";

if ($search) {
    $query .= " AND (title LIKE '%$search%' OR category LIKE '%$search%' OR location LIKE '%$search%')";
}
if ($category) {
    $query .= " AND category = '$category'";
}
if ($location) {
    $query .= " AND location = '$location'";
}

$query .= " ORDER BY posted_at DESC";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Available Jobs - EmpowerHub</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { font-family: 'Arial', sans-serif; background-color: #f4f4f4; }
        .container { margin-top: 30px; }
        .hero-section {
            background: linear-gradient(to right, #007bff, #6610f2);
            color: white;
            padding: 50px;
            text-align: center;
            border-radius: 10px;
        }
        .search-bar, .filters {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 20px;
        }
        .job-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            transition: 0.3s;
        }
        .job-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
        }
        .job-title { font-size: 1.4rem; color: #007bff; }
        .job-desc { font-size: 0.95rem; }
        .apply-btn, .save-btn {
            padding: 8px 15px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 500;
            transition: 0.3s;
        }
        .apply-btn { background: #007bff; color: white; }
        .apply-btn:hover { background: #0056b3; }
        .save-btn { background: #28a745; color: white; }
        .save-btn:hover { background: #218838; }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="Index.php">EmpowerHub</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Mentors</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Contact</a></li>
            </ul>
        </div>
    </div>
</nav>

    <div class="hero-section">
        <h1>Find Your Dream Job</h1>
        <p>Discover the best career opportunities tailored for you.</p>
    </div>

    <!-- Filters -->
    <div class="container">
        <form class="search-bar" method="GET" action="">
            <input type="text" name="search" class="form-control" placeholder="Search by title, category, location..." value="<?= htmlspecialchars($search) ?>">
            <select name="category" class="form-select">
                <option value="">All Categories</option>
                <option value="IT">IT</option>
                <option value="Finance">Finance</option>
            </select>
            <select name="location" class="form-select">
                <option value="">All Locations</option>
                <option value="Colombo">Colombo</option>
                <option value="Kandy">Kandy</option>
                <option value="Negombo">Negombo</option>
                <option value="Galle">Galle</option>
                <option value="Matara">Matara</option>
                <option value="Gampaha">Gampaha</option>
            </select>
            <button type="submit" class="btn btn-primary">Search</button>
        </form>
    </div>

    <div class="container mt-4">
        <div class="row">
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="col-md-4">
                    <div class="job-card p-3 mb-4">
                        <h5 class="job-title"><?= htmlspecialchars($row['title']) ?></h5>
                        <p class="text-muted"><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($row['location']) ?> | <?= htmlspecialchars($row['category']) ?></p>
                        <p class="job-desc"> <?= nl2br(htmlspecialchars(substr($row['description'], 0, 100))) ?>...</p>
                        <div class="d-flex justify-content-between">
                            <a href="job_details.php?id=<?= $row['id'] ?>" class="apply-btn btn">View & Apply</a>
                           <!--<button class="save-btn btn"><i class="fas fa-heart"></i> Save</button> -->
                            <button class="save-btn btn" onclick="saveAction()"><i class="fas fa-heart"></i> Save</button>

                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
</body>
</html>
<script>
    function saveAction() {
    const itemToSave = "Sample Data";  // The data you want to save
    
    // Save it to localStorage
    localStorage.setItem('savedItem', itemToSave);
    
    // Provide feedback to the user
    alert("Your item has been saved in localStorage!");
}

const savedItem = localStorage.getItem('savedItem');
console.log(savedItem);  // Output: Sample Data

</script>