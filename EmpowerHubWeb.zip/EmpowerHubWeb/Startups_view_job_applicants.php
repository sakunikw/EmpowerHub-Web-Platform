<?php
session_start();
include 'Connection_db.php';

$startup_email = $_SESSION['email'];

$stmt = $conn->prepare("SELECT a.*, j.title FROM job_applications a 
  JOIN job_postings j ON a.job_id = j.id 
  WHERE j.startup_email = ?");
$stmt->bind_param("s", $startup_email);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Applications Received</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

  <style>
    body {
      background-color: #f8f9fa;
      font-family: 'Segoe UI', sans-serif;
    }
    
    .container {
      margin-top: 40px;
    }

    .card {
      border-radius: 10px;
      border: none;
      box-shadow: 0px 4px 10px rgba(0,0,0,0.1);
    }

    .card-header {
      background: linear-gradient(to right, #007bff, #6610f2);
      color: white;
      padding: 15px;
      border-radius: 10px 10px 0 0;
    }

    .btn-download {
      background-color: #28a745;
      color: white;
      padding: 8px 12px;
      border-radius: 5px;
      text-decoration: none;
      transition: background 0.3s ease-in-out;
    }

    .btn-download:hover {
      background-color: #218838;
      color: white;
    }

    .btn-delete {
      background-color: #dc3545;
      color: white;
      padding: 8px 12px;
      border-radius: 5px;
      transition: background 0.3s ease-in-out;
    }

    .btn-delete:hover {
      background-color: #c82333;
    }

    .btn-select {
      background-color: #007bff;
      color: white;
      padding: 8px 12px;
      border-radius: 5px;
      transition: background 0.3s ease-in-out;
    }

    .btn-select:hover {
      background-color: #0056b3;
    }
  </style>
</head>
<body>


<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="#">EmpowerHub</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link active" href="startups_dashboard.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="startup_view_selected_applicants.php">Selected Applicants</a></li>
                <li class="nav-item"><a class="nav-link" href="startups_view_job_applicants.php">All Applicants</a></li>

                
            </ul>
        </div>
    </div>
</nav>

  <div class="container">
    <h2 class="text-center mb-4">Applications Received</h2>
    
    <?php while ($row = $result->fetch_assoc()) { ?>
      <div class="card mb-4">
        <div class="card-header">
          <h4><?= htmlspecialchars($row['title']) ?></h4>
        </div>
        <div class="card-body">
          <p><strong>Applicant:</strong> <?= htmlspecialchars($row['applicant_name']) ?> (<?= htmlspecialchars($row['applicant_email']) ?>)</p>
          <p><strong>Cover Letter:</strong> <?= nl2br(htmlspecialchars($row['cover_letter'])) ?></p>
          <p><strong>Applied At:</strong> <?= $row['application_date'] ?></p>
          <p><strong>Resume:</strong> 
            <?php if (!empty($row['cv_file'])) { ?>
              <a href="<?= htmlspecialchars($row['cv_file']) ?>" class="btn btn-download" download>Download CV</a>
            <?php } else { ?>
              <span class="text-muted">No CV uploaded</span>
            <?php } ?>
          </p>

          <!-- Select and Delete Buttons -->
          <button class="btn btn-select" data-id="<?= $row['id'] ?>">Select</button>
          <button class="btn btn-delete" data-id="<?= $row['id'] ?>">Delete</button>
        </div>
      </div>
    <?php } ?>
  </div>

  <script>
    $(document).ready(function () {
      // Delete Applicant
      $(".btn-delete").click(function () {
        var appId = $(this).data("id");
        var card = $(this).closest(".card");

        if (confirm("Are you sure you want to delete this application?")) {
          $.ajax({
            url: "startup_delete_applicant.php",
            type: "POST",
            data: { id: appId },
            success: function (response) {
              if (response === "success") {
                card.fadeOut(500, function () { $(this).remove(); });
              } else {
                alert("Failed to delete application.");
              }
            }
          });
        }
      });

      // Select Applicant
      $(".btn-select").click(function () {
        var appId = $(this).data("id");
        var card = $(this).closest(".card");

        if (confirm("Are you sure you want to select this applicant?")) {
          $.ajax({
            url: "startup_select_applicant.php",
            type: "POST",
            data: { id: appId },
            success: function (response) {
              if (response === "success") {
                card.fadeOut(500, function () { $(this).remove(); });
              } else {
                alert("Failed to select applicant.");
              }
            }
          });
        }
      });

    });
  </script>

</body>
</html>
