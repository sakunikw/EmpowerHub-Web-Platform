<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - EmpowerHub</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            color: #333;
            font-family: 'Poppins', sans-serif;
        }
        .about-header {
            background: linear-gradient(to right, #007bff, #6610f2);
            color: white;
            padding: 60px 0;
            text-align: center;
        }
        .about-header h1 {
            font-size: 3rem;
            font-weight: bold;
        }
        .about-section {
            padding: 60px 0;
        }
        .about-section h2 {
            color: #007bff;
            font-weight: bold;
        }
        .list-group-item {
            background-color: #fff;
            border-left: 5px solid #007bff;
        }
        .cta-section {
            text-align: center;
            margin-top: 50px;
        }
        .cta-button {
            background: #007bff;
            color: white;
            padding: 14px 30px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            transition: 0.3s;
        }
        .cta-button:hover {
            background: #0056b3;
            transform: scale(1.05);
        }
        .team-section {
            background-color: #e9ecef;
            padding: 60px 0;
            text-align: center;
        }
        .team-member {
            padding: 20px;
        }
        .team-member img {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            margin-bottom: 15px;
        }
        .team-member h5 {
            font-weight: bold;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="Index.php">EmpowerHub</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Mentors</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Contact</a></li>
            </ul>
        </div>
    </div>
</nav>

    <div class="about-header">
        <h1>About EmpowerHub</h1>
        <p>Connecting mentors, entrepreneurs, investors, and job seekers for a thriving business ecosystem.</p>
    </div>

    <div class="container about-section">
        <div class="row align-items-center">
            <div class="col-md-6">
                <img src="assets/images/about.jpg" class="img-fluid rounded shadow" alt="About EmpowerHub">
            </div>
            <div class="col-md-6">
                <h2>Our Mission</h2>
                <p>
                    EmpowerHub is dedicated to fostering economic growth, innovation, and personal development by providing a platform
                    where experienced mentors, new business starters, investors, and job seekers can connect and collaborate.
                </p>
            </div>
        </div>

        <div class="row mt-5">
            <div class="col-md-6">
                <h2>Our Vision</h2>
                <p>
                    We envision a world where aspiring entrepreneurs receive guidance, investors find promising projects, and professionals
                    discover meaningful career opportunities—all through a single, dynamic platform.
                </p>
            </div>
            <div class="col-md-6">
                <h2>What We Offer</h2>
                <ul class="list-group">
                    <li class="list-group-item"><strong>Mentorship:</strong> Connect with experienced mentors for business guidance.</li>
                    <li class="list-group-item"><strong>Investment Opportunities:</strong> Investors can discover and fund promising startups.</li>
                    <li class="list-group-item"><strong>Job Matching:</strong> AI-powered system to match job seekers with employers.</li>
                    <li class="list-group-item"><strong>Business Consulting:</strong> Expert consulting sessions for entrepreneurs.</li>
                </ul>
            </div>
        </div>
    </div>

    <div class="team-section">
        <h2 class="fw-bold">Meet Our Team</h2>
        <p>Our dedicated team works tirelessly to make EmpowerHub a success.</p>
        <div class="container">
            <div class="row">
                <div class="col-md-4 team-member">
                    <img src="assets/images/team1.jpg" alt="Team Member">
                    <h5>Jane Doe</h5>
                    <p>Founder & CEO</p>
                </div>
                <div class="col-md-4 team-member">
                    <img src="assets/images/team2.jpg" alt="Team Member">
                    <h5>John Smith</h5>
                    <p>Chief Technology Officer</p>
                </div>
                <div class="col-md-4 team-member">
                    <img src="assets/images/team3.jpg" alt="Team Member">
                    <h5>Emma Brown</h5>
                    <p>Head of Marketing</p>
                </div>
            </div>
        </div>
    </div>

    <div class="cta-section">
        <a href="contact.html" class="cta-button">Get in Touch</a>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
