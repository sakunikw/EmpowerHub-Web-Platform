<?php
session_start();

// Check if the mentor is logged in
if (isset($_SESSION['user_id'])) {
    // Destroy the session to log out
    session_unset(); // Unsets all session variables
    session_destroy(); // Destroys the session

    // Redirect to the login page
    echo "<script>alert('You have been logged out successfully.'); window.location.href='MentorSignIn.php';</script>";
    exit();
} else {
    // If no session exists, redirect to the login page directly
    header("Location: MentorSignIn.php");
    exit();
}
?>
