<?php
session_start();
include 'Connection_db.php';

if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    echo "<script>alert('You need to be logged in as a mentor to view this page.'); window.location.href='MentorSignIn.php';</script>";
    exit();
}

$mentor_id = $_SESSION['user_id'];
$current_date = date("Y-m-d");

$search_name = isset($_GET['search_name']) ? $_GET['search_name'] : '';
$search_date = isset($_GET['search_date']) ? $_GET['search_date'] : '';

// Dynamic SQL with filters
$sql = "SELECT * FROM consultation_requests WHERE mentor_id = ? AND status = 'Approved' AND date >= ?";
$params = [$mentor_id, $current_date];
$types = "is";

if (!empty($search_name)) {
    $sql .= " AND name LIKE ?";
    $params[] = "%$search_name%";
    $types .= "s";
}

if (!empty($search_date)) {
    $sql .= " AND date = ?";
    $params[] = $search_date;
    $types .= "s";
}

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Approved Requests</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f0f2f5;
        }

        .navbar {
            background-color: #343a40;
        }

        .navbar-brand, .nav-link {
            color: #fff !important;
        }

        .footer {
            background-color: #343a40;
            color: #fff;
            padding: 15px 0;
            margin-top: 50px;
            text-align: center;
        }

        .container {
            margin-top: 40px;
        }

        .request-card {
            background-color: #fff;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }

        .btn-success, .btn-primary {
            border-radius: 8px;
        }

        .search-bar {
            margin-bottom: 30px;
        }

        @media (max-width: 768px) {
            .request-card {
                padding: 15px;
            }
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Mentor Portal</a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="MentorHome.php">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="MentorSignOut.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- Main Content -->
<div class="container">
    <h2 class="text-center mb-4">Upcoming Mentorship Sessions</h2>

    <!-- Search Form -->
    <form method="GET" class="row search-bar g-3">
        <div class="col-md-4">
            <input type="text" name="search_name" class="form-control" placeholder="Search by Name" value="<?= htmlspecialchars($search_name) ?>">
        </div>
        <div class="col-md-4">
            <input type="date" name="search_date" class="form-control" value="<?= htmlspecialchars($search_date) ?>">
        </div>
        <div class="col-md-4 d-flex gap-2">
            <button type="submit" class="btn btn-primary">Search</button>
            <a href="mentor_accepted_requests.php" class="btn btn-secondary">Reset</a>
        </div>
    </form>

    <hr>

    <?php if ($result->num_rows > 0): ?>
        <div class="row">
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="col-md-6">
                    <div class="request-card">
                        <h5><?php echo htmlspecialchars($row['name']); ?></h5>
                        <p><strong>Email:</strong> <?= htmlspecialchars($row['email']) ?></p>
                        <p><strong>Date:</strong> <?= htmlspecialchars($row['date']) ?></p>
                        <p><strong>Time:</strong> <?= htmlspecialchars($row['time']) ?></p>
                        <p><strong>Message:</strong><br><?= nl2br(htmlspecialchars($row['message'])) ?></p>
                        <button class="btn btn-success mt-2 start-call" data-url="video_call.php?request_id=<?= $row['id'] ?>">Start Video Call</button>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <p class="text-center text-muted">No mentorship sessions found for your filters.</p>
    <?php endif; ?>

    <div class="text-center mt-4">
        <a href="MentorHome.php" class="btn btn-primary">Back to Dashboard</a>
    </div>
</div>

<!-- Footer -->
<div class="footer">
    &copy; <?= date("Y") ?> Mentor Portal | All Rights Reserved
</div>

<!-- Scripts -->
<script>
    document.querySelectorAll('.start-call').forEach(button => {
        button.addEventListener('click', function () {
            const callUrl = this.getAttribute('data-url');
            if (confirm("Are you sure you want to start the video call?")) {
                window.location.href = callUrl;
            }
        });
    });
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
