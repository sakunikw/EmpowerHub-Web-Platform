<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Innovator Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .dashboard-container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        .section {
            margin-top: 30px;
            padding: 20px;
            background: #ffffff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <?php
    session_start();
    if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'innovator') {
        header("Location: invest_signin.php");
        exit();
    }
    ?>
    
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">EmpowerHub</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <div class="dashboard-container text-center">
            <h2>Welcome, <?php echo htmlspecialchars($_SESSION['fullname']); ?>!</h2>
            <p>This is your Innovator Dashboard where you can manage your projects and connect with investors.</p>
            <a href="logout.php" class="btn btn-danger">Logout</a>
        </div>
        
        <div class="section">
            <h3>Submit Project</h3>
            <p>Submit your innovation projects.</p>
            <a href="innovator_submit_project.php" class="btn btn-primary">Submit Projects</a>
        </div>

        <div class="section">
            <h3>My Project</h3>
            <p>Manage and update your innovation projects.</p>
            <a href="innovator_projects.php" class="btn btn-primary">View Projects</a>
        </div>
        
        <div class="section">
            <h3>Investor Connections</h3>
            <p>Connect with investors interested in your innovations.</p>
            <a href="#" class="btn btn-success">Find Investors</a>
        </div>
        
        <div class="section">
            <h3>Resources</h3>
            <p>Access useful articles, templates, and guidance.</p>
            <a href="#" class="btn btn-info">Explore Resources</a>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
