<?php
include 'Connection_db.php';

$sql = "SELECT * FROM mentor_verification WHERE status = 'approved'";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verified Mentors - EmpowerHub</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        /* General Styling */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            text-align: center;
        }

        .container {
            width: 90%;
            max-width: 1200px;
            margin: auto;
            padding: 20px;
        }

        /* Header */
        .header {
            background: #007bff;
            color: white;
            padding: 20px;
            border-radius: 8px;
            position: relative;
            margin-bottom: 20px;
            text-align: center;
        }

        .header h1 {
            margin: 0;
            font-size: 26px;
        }

        .header p {
            font-size: 16px;
            margin-top: 5px;
            opacity: 0.9;
        }

        /* Back Button */
        .back-button {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            background-color: #28a745;
            color: white;
            border: none;
            padding: 10px 15px;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s;
        }

        .back-button:hover {
            background-color: #218838;
        }

        /* Mentor Cards */
        .mentor-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            padding: 20px 0;
        }

        .mentor-box {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            padding: 20px;
            text-align: center;
            transition: 0.3s;
            position: relative;
        }

        .mentor-box:hover {
            transform: translateY(-5px);
        }

        .mentor-img {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 10px;
            border: 3px solid #007bff;
        }

        .mentor-details h3 {
            margin: 10px 0;
            color: #333;
        }

        .mentor-details p {
            margin: 5px 0;
            font-size: 14px;
            color: #555;
        }

        .mentor-details a {
            display: inline-block;
            margin-top: 8px;
            color: #007bff;
            text-decoration: none;
            font-weight: bold;
        }

        .mentor-details a:hover {
            text-decoration: underline;
        }

        .request-btn {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 15px;
            cursor: pointer;
            border-radius: 5px;
            font-size: 14px;
            margin-top: 10px;
            transition: background 0.3s;
        }

        .request-btn:hover {
            background-color: #0056b3;
        }

        /* Responsive Design */
        @media (max-width: 600px) {
            .header h1 {
                font-size: 22px;
            }
            .header p {
                font-size: 14px;
            }
            .back-button {
                font-size: 14px;
                padding: 8px 12px;
            }
        }
    </style>
</head>
<body>

    <div class="header">
        
        <button class="back-button" onclick="goBack()">← Back</button>
        <h1>Meet Our Verified Mentors</h1>
        <p>EmpowerHub ensures that all our mentors are professionally verified to guide and support you.</p>
    </div>

    <div class="container">
        <div class="mentor-grid">
            <?php while ($row = $result->fetch_assoc()) { ?>
                <div class="mentor-box">
                    <img class="mentor-img" src="<?php echo !empty($row['profile_picture']) ? $row['profile_picture'] : 'default-avatar.png'; ?>" alt="Mentor Image">
                    
                    <div class="mentor-details">
                        <h3><?php echo htmlspecialchars($row['full_name']); ?></h3>
                        <p><strong>Email:</strong> <?php echo htmlspecialchars($row['email']); ?></p>
                        <p><strong>Phone:</strong> <?php echo htmlspecialchars($row['phone']); ?></p>
                        <p><strong>Country:</strong> <?php echo htmlspecialchars($row['country']); ?></p>
                        <p><strong>Experience:</strong> <?php echo htmlspecialchars($row['experience']); ?> years</p>
                        <p><strong>Industry:</strong> <?php echo htmlspecialchars($row['industry']); ?></p>
                        <p><strong>Bio:</strong> <?php echo nl2br(htmlspecialchars($row['bio'])); ?></p>
                        <p><a href="<?php echo htmlspecialchars($row['linkedin']); ?>" target="_blank">🔗 View LinkedIn Profile</a></p>
                        <button class="request-btn" onclick="requestSession(<?php echo $row['id']; ?>)">Request a Session</button>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>

    <script>
        function goBack() {
            window.location.href = 'Index.php'; // Redirect to the homepage
        }

        function requestSession(mentorId) {
            window.location.href = 'request_session.php?mentor_id=' + mentorId;
        }
    </script>

</body>
</html>
<?php $conn->close(); ?>
