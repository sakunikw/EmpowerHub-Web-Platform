<?php
session_start();
include 'Connection_db.php';

if (isset($_POST['update_mentor'])) {
    $id = $_POST['mentor_id'];
    $name = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password']; // Ideally, hash passwords before storing them

    $sql = "UPDATE mentors SET username = ?, email = ?, password = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssi", $name, $email, $password, $id);

    if ($stmt->execute()) {
        $_SESSION['message'] = "Mentor updated successfully!";
    } else {
        $_SESSION['message'] = "Error updating mentor.";
    }

    header("Location: Admin_manage_users.php");
    exit();
}
?>
