<?php
require 'connection_db.php';

if (isset($_POST['approve'])) {
    $project_id = $_POST['project_id'];
    $conn->query("UPDATE projects SET status='approved' WHERE id=$project_id");
}
if (isset($_POST['reject'])) {
    $project_id = $_POST['project_id'];
    $conn->query("UPDATE projects SET status='pending' WHERE id=$project_id");
}

$result = $conn->query("SELECT * FROM projects WHERE status='pending'");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin - Approve Projects</title>
</head>
<body>
    <h2>Pending Projects</h2>
    <table>
        <tr>
            <th>Title</th>
            <th>Description</th>
            <th>Actions</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?php echo $row['title']; ?></td>
            <td><?php echo $row['description']; ?></td>
            <td>
                <form method="POST">
                    <input type="hidden" name="project_id" value="<?php echo $row['id']; ?>">
                    <button type="submit" name="approve">Approve</button>
                    <button type="submit" name="reject">Reject</button>
                </form>
            </td>
        </tr>
        <?php } ?>
    </table>
</body>
</html>
