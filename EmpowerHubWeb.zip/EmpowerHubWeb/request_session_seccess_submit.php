<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Request Submitted</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h2>Your consultation request has been successfully submitted!</h2>
        <p>You will be notified once your mentor approves or rejects your request.</p>
        <a href="index.php">Go back to home</a>
    </div>
</body>
</html>
