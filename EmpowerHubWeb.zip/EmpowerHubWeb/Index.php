<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
    <title>EmpowerHub - Landing Page</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
  
    <link rel="stylesheet" href="script.js">


    
</head>
<body>
    <!-- Navbar Section -->
    <nav class="navbar">
        <div class="navbar-container">
            <a href="#" class="logo">Empower<span>Hub</span></a>

            <ul class="nav-links">
                <li><a href="#home">Home</a></li>
                <li><a href="#about">About</a></li>
                <li><a href="#resources">Resources</a></li>
                <li><a href="Mentor_panel.php">Meet Our Consultants</a></li>
            </ul>
        </div>
    </nav>

    <!-- Hero Section -->
    <header class="hero-section" id="home">
        <div class="hero-overlay">
            <div class="hero-text">
                <h1>Empowering Growth & Innovation</h1>
                <p>Connecting entrepreneurs, job seekers, and mentors to shape the future of business.</p>

                
                <div class="cta-buttons">
                    <a href="#learn-more" class="btn-primary">Learn More</a>
                    <a href="#join-us" class="btn-secondary">Join Us</a>
                </div>
            </div>
        </div>
    </header>

    <section class="mentor-section">
        <div class="mentor-content">
            <h2>Would You Like to Be a Mentor?</h2>
            <p>
                Empower and inspire the next generation of entrepreneurs!  
                As a mentor, you’ll have the opportunity to share your expertise,  
                guide small business starters, and contribute to their success.  
                Join us in building a stronger business community.
            </p>
            <a href="MentorSignIn.php" class="mentor-btn">Become a Mentor</a>
        </div>
    </section>


    <!-- How It Works Section -->
<section id="how-it-works" class="how-it-works-section">
    <div class="container">
        <h2>How It Works</h2>
        <div class="steps-container">
            <!-- Step 1 -->
            <div class="step">
                <div class="step-image">
                    <img src="images/i1.jpg" alt="Create Your Profile">
                </div>
                <div class="step-content">
                    <div class="step-number">STEP 1</div>
                    <h3>Build Your Professional Identity</h3>
                    <p>Getting started is easy! Create a personalized profile that highlights your professional achievements, skills, or business aspirations. Showcase what you do best and make meaningful connections right from the start.</p>
                </div>
            </div>

            <!-- Step 2 -->
            <div class="step reverse">
                <div class="step-image">
                    <img src="images/img7.jpg" alt="Connect with Others">
                </div>
                <div class="step-content">
                    <div class="step-number">STEP 2</div>
                    <h3>Expand Your Network</h3>
                    <p>Now that your profile is ready, it’s time to explore the vast world of opportunities. Connect with seasoned mentors, potential investors, and motivated job seekers. Build relationships that can accelerate your growth and open doors to exciting collaborations.</p>
                </div>
            </div>

            <!-- Step 3 -->
            <div class="step">
                <div class="step-image">
                    <img src="images/img2.jpg" alt="Grow Your Business">
                </div>
                <div class="step-content">
                    <div class="step-number">STEP 3</div>
                    <h3>Empower Your Growth</h3>
                    <p>With the support and resources you’ve gathered, it’s time to take the next step. Whether it’s scaling your business, advancing your career, or creating new opportunities, use the tools and knowledge at your disposal to fuel your progress and reach new heights of success.</p>
                </div>
            </div>
        </div>
    </div>
</section>



<section class="about-us">
    <div class="container">
      <div class="about-text">
        <h2>About <span>EmpowerHub</span></h2>
        <p>
          EmpowerHub is a unique platform bridging the gap between entrepreneurs, mentors, job seekers, and investors. 
          By fostering innovation and collaboration, we empower individuals to turn their visions into reality and thrive in competitive markets.
        </p>
        <p>
          Our mission is to provide a comprehensive ecosystem of mentorship, investment, and networking opportunities, 
          empowering individuals and businesses to unlock their full potential.
        </p>
        <a href="#learn-more" class="cta-button">Learn More</a>
      </div>
      <div class="about-image">
        <img src="" alt="" />
      </div>
    </div>
  </section>

  <!-- Carousel Section -->
<section id="carousel" class="carousel-section">
    <div class="container">
      <h2>EmpowerHub in Action</h2>
      <p>See how EmpowerHub connects entrepreneurs, job seekers, and investors.</p>
  
      <div class="carousel-wrapper">
        <div class="carousel">
          <div class="carousel-item">
            <img src="images/i2.jpeg" alt="Mentorship Session">
            <div class="overlay">
              <p>Mentorship Session</p>
            </div>
          </div>
          <div class="carousel-item">
            <img src="images/i3.jpeg" alt="Job Fair">
            <div class="overlay">
              <p>Job Fair Event</p>
            </div>
          </div>
          <div class="carousel-item">
            <img src="images/i6.jpeg" alt="Investor Meeting">
            <div class="overlay">
              <p>Pitching Ideas to Investors</p>
            </div>
          </div>
          <div class="carousel-item">
            <img src="images/i2.jpeg" alt="Workshop">
            <div class="overlay">
              <p>Interactive Workshop</p>
            </div>
          </div>
        </div>
  
        <!-- Navigation Buttons -->
        <button class="prev">&#10094;</button>
        <button class="next">&#10095;</button>
      </div>
    </div>
</section>



    <!-- Features Section -->
<section id="features" class="features-section">
    <div class="container">
        <h2>Our Key Features</h2>
        <div class="features-container">
            <!-- Feature Box 1 -->
            <div class="feature-box feature-1">
                <a href="Mentor_panel.php">
                    <h3>Mentorship</h3>
                    <p>Connect with experienced mentors who guide you through your business journey.</p>
                </a>
            </div>
            <!-- Feature Box 2 -->
            <div class="feature-box feature-2">
                <a href="#job-opportunities">
                    <h3>Job Opportunities</h3>
                    <p>Discover job opportunities and internships tailored to your career goals.</p>
                </a>
            </div>
            <!-- Feature Box 3 -->
            <div class="feature-box feature-3">
                <a href="InvestorLogin.html">
                    <h3>Investment Opportunities</h3>
                    <p>Find investors and venture capitalists to support your business growth.</p>
                </a>
            </div>
            
            <!-- Feature Box 5 -->
            <div class="feature-box feature-5">
                <a href="#workshops">
                    <h3>Workshops & Training</h3>
                    <p>Access workshops and training to help you improve your skills and business acumen.</p>
                </a>
            </div>

            <!-- Feature Box 5 -->
            <div class="feature-box feature-6">
                <a href="#workshops">
                    <h3>Workshops & Training</h3>
                    <p>Access workshops and training to help you improve your skills and business acumen.</p>
                </a>
            </div>
            <div class="feature-box feature-6">
                <a href="#workshops">
                    <h3>Workshops & Training</h3>
                    <p>Access workshops and training to help you improve your skills and business acumen.</p>
                </a>
            </div>
            
        </div>
    </div>
</section>
<!-- Footer Section -->
<footer class="footer">
    <div class="container">
        <div class="footer-content">
            <!-- Footer Logo and Description -->
            <div class="footer-logo">
                <h2>Empower<span>Hub</span></h2>
                <p>Connecting entrepreneurs, job seekers, and investors to shape the future of business.</p>
            </div>

            <!-- Quick Links -->
            <div class="footer-links">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="#home">Home</a></li>
                    <li><a href="#features">Features</a></li>
                    <li><a href="#about">About</a></li>
                    <li><a href="#contact">Contact</a></li>
                </ul>
            </div>

            <!-- Contact Information -->
            <div class="footer-contact">
                <h3>Contact Us</h3>
                <p>Email: support@empowerhub.com</p>
                <p>Phone: +123 456 7890</p>
                <p>Location: City Name, Country</p>
            </div>

            <!-- Social Media Links -->
            <div class="footer-social">
                <h3>Follow Us</h3>
                <div class="social-icons">
                    <a href="#" target="_blank"><img src="images/facebook-icon.png" alt="Facebook"></a>
                    <a href="#" target="_blank"><img src="images/twitter-icon.png" alt="Twitter"></a>
                    <a href="#" target="_blank"><img src="images/linkedin-icon.png" alt="LinkedIn"></a>
                    <a href="#" target="_blank"><img src="images/instagram-icon.png" alt="Instagram"></a>
                </div>
            </div>
        </div>

        <!-- Copyright Section -->
        <div class="footer-bottom">
            <p>&copy; 2025 EmpowerHub. All Rights Reserved.</p>
        </div>
    </div>
</footer>




 

 
<script>

    
let currentIndex = 0;
const items = document.querySelectorAll('.carousel-item');
const totalItems = items.length;

function showItem(index) {
  // Hide all items
  items.forEach(item => item.style.display = 'none');
  
  // Show the current item
  items[index].style.display = 'block';
}

// Initially show the first item
showItem(currentIndex);

// Next button functionality
document.querySelector('.next').addEventListener('click', () => {
  currentIndex = (currentIndex + 1) % totalItems; // Loop back to the first item
  showItem(currentIndex);
});

// Previous button functionality
document.querySelector('.prev').addEventListener('click', () => {
  currentIndex = (currentIndex - 1 + totalItems) % totalItems; // Loop back to the last item
  showItem(currentIndex);
});








</script>
</body>
</html>
